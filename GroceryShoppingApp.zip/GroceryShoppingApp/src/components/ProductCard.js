import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, SHADOWS } from '../utils/theme';

export default function ProductCard({
  product,
  onPress,
  onAddToCart,
  onToggleFavorite,
  isFavorite = false,
  isCustomer = false,
  quantityInCart = 0,
}) {
  const [imageError, setImageError] = useState(false);
  const [imageLoading, setImageLoading] = useState(true);

  return (
    <TouchableOpacity
      style={styles.card}
      onPress={onPress}
      activeOpacity={isCustomer ? 0.75 : 0.95}
    >
      {/* Product Image & Floating Favorite Overlay */}
      <View style={styles.imageContainer}>
        {imageError ? (
          <View style={styles.fallbackContainer}>
            <Ionicons name="basket-outline" size={40} color="#A3B18A" />
          </View>
        ) : (
          <>
            <Image
              source={{ uri: product.image }}
              style={styles.image}
              resizeMode="cover"
              onLoadEnd={() => setImageLoading(false)}
              onError={() => {
                setImageLoading(false);
                setImageError(true);
              }}
            />
            {imageLoading && (
              <View style={styles.loaderContainer}>
                <ActivityIndicator size="small" color={COLORS.primary} />
              </View>
            )}
          </>
        )}

        {/* Favorite Icon (Customer Only) */}
        {isCustomer && (
          <TouchableOpacity
            style={styles.favoriteBtn}
            onPress={onToggleFavorite}
            activeOpacity={0.7}
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
          >
            <Ionicons
              name={isFavorite ? 'heart' : 'heart-outline'}
              size={18}
              color={isFavorite ? COLORS.heartRed : '#757575'}
            />
          </TouchableOpacity>
        )}
      </View>

      {/* Product Details Content */}
      <View style={styles.content}>
        {/* Category & Rating Row */}
        <View style={styles.metaRow}>
          <Text style={styles.categoryBadge}>{product.category}</Text>
          <View style={styles.ratingBadge}>
            <Ionicons name="star" size={11} color="#FFA000" />
            <Text style={styles.ratingText}>{product.rating || 4.8}</Text>
          </View>
        </View>

        {/* Product Name */}
        <Text style={styles.name} numberOfLines={2}>
          {product.name}
        </Text>

        {/* Unit Info */}
        <Text style={styles.unitText}>{product.unit || '1 unit'}</Text>

        {/* Price & Add to Cart Row */}
        <View style={styles.priceRow}>
          <Text style={styles.priceSymbol}>
            ₹<Text style={styles.priceText}>{product.price}</Text>
          </Text>

          {/* Add to Cart Button (Customer Only) or In Stock Badge (Admin) */}
          {isCustomer ? (
            <TouchableOpacity
              style={[
                styles.addCartBtn,
                quantityInCart > 0 && styles.addCartBtnInCart,
              ]}
              onPress={onAddToCart}
              activeOpacity={0.8}
              hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}
            >
              <Ionicons
                name={quantityInCart > 0 ? 'checkmark' : 'add'}
                size={18}
                color="#FFFFFF"
              />
              {quantityInCart > 0 ? (
                <Text style={styles.cartQtyBadgeText}>{quantityInCart}</Text>
              ) : null}
            </TouchableOpacity>
          ) : (
            <View style={styles.inStockBadge}>
              <Text style={styles.inStockText}>In Stock</Text>
            </View>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    margin: 6,
    borderWidth: 1,
    borderColor: '#EDE8DB',
    overflow: 'hidden',
    ...SHADOWS.sm,
  },
  imageContainer: {
    width: '100%',
    height: 128,
    backgroundColor: '#FAF7F0',
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  loaderContainer: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(250, 247, 240, 0.7)',
  },
  fallbackContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    height: '100%',
    backgroundColor: '#EBF0E6',
  },
  favoriteBtn: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.12,
    shadowRadius: 3,
    elevation: 2,
  },
  content: {
    padding: 12,
  },
  metaRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  categoryBadge: {
    fontSize: 10,
    fontWeight: '700',
    color: '#A3B18A',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  ratingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FDF6E7',
    paddingHorizontal: 5,
    paddingVertical: 1,
    borderRadius: 6,
    gap: 2,
  },
  ratingText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#7A541A',
  },
  unitText: {
    fontSize: 11,
    color: '#56655A',
    fontWeight: '500',
    marginBottom: 8,
  },
  name: {
    fontSize: 13,
    fontWeight: '700',
    color: '#26352B',
    lineHeight: 18,
    minHeight: 36,
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  priceSymbol: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#344E41',
  },
  priceText: {
    fontSize: 17,
    fontWeight: '800',
  },
  addCartBtn: {
    backgroundColor: '#D97757',
    width: 32,
    height: 32,
    borderRadius: 10,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#D97757',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3,
    elevation: 2,
  },
  addCartBtnInCart: {
    backgroundColor: '#C25E3E',
    width: 44,
    paddingHorizontal: 4,
    gap: 2,
  },
  cartQtyBadgeText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  inStockBadge: {
    backgroundColor: '#EBF0E6',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#CCD6BD',
  },
  inStockText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#344E41',
  },
});
