import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { DEFAULT_ADMIN } from '../data/defaultAdmin';
import { hashPassword, verifyPassword } from '../utils/security';

const AuthContext = createContext();

const STORAGE_CUSTOMERS_KEY = '@grocery_registered_customers';
const STORAGE_SESSION_KEY = '@grocery_active_session';

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [registeredCustomers, setRegisteredCustomers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize storage: load registered customers and restore any active session
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        const storedCustomers = await AsyncStorage.getItem(STORAGE_CUSTOMERS_KEY);
        if (storedCustomers) {
          setRegisteredCustomers(JSON.parse(storedCustomers));
        }

        const storedSession = await AsyncStorage.getItem(STORAGE_SESSION_KEY);
        if (storedSession) {
          const session = JSON.parse(storedSession);
          if (session && session.user && session.role) {
            setCurrentUser(session.user);
            setUserRole(session.role);
            setIsAuthenticated(true);
          }
        }
      } catch (error) {
        console.warn('Error reading auth state from AsyncStorage:', error);
      } finally {
        setIsLoading(false);
      }
    };

    initializeAuth();
  }, []);

  /**
   * Register a new Customer.
   * Customer is the only role permitted to sign up.
   * Passwords are never stored in plain text.
   */
  const registerCustomer = async ({ name, email, phone, password }) => {
    const normalizedEmail = email.trim().toLowerCase();
    const adminNormalizedEmail = DEFAULT_ADMIN.email.trim().toLowerCase();

    // Prevent registering with the predefined Admin email
    if (normalizedEmail === adminNormalizedEmail) {
      return {
        success: false,
        error: 'This email is reserved for the Admin account. Please use a different email or sign in as Admin.',
      };
    }

    // Prevent duplicate email registration
    const existingUser = registeredCustomers.find(
      (c) => c.email.trim().toLowerCase() === normalizedEmail
    );
    if (existingUser) {
      return {
        success: false,
        error: 'An account with this email already exists. Please sign in or use another email.',
      };
    }

    // Create new customer account with hashed password
    const newCustomer = {
      id: `cust_${Date.now()}`,
      name: name.trim(),
      email: normalizedEmail,
      phone: phone.trim(),
      role: 'Customer',
      passwordHash: hashPassword(password),
      createdAt: new Date().toISOString(),
    };

    const updatedList = [...registeredCustomers, newCustomer];
    setRegisteredCustomers(updatedList);

    try {
      await AsyncStorage.setItem(STORAGE_CUSTOMERS_KEY, JSON.stringify(updatedList));
    } catch (error) {
      console.warn('Error saving customer to AsyncStorage:', error);
    }

    return {
      success: true,
      message: 'Registration successful! You can now sign in with your credentials.',
    };
  };

  /**
   * Login with email, password, and target role.
   */
  const login = async ({ email, password, role }) => {
    const normalizedEmail = email.trim().toLowerCase();
    const adminNormalizedEmail = DEFAULT_ADMIN.email.trim().toLowerCase();

    if (role === 'Admin') {
      // Check if credentials match the predefined Admin
      if (normalizedEmail !== adminNormalizedEmail) {
        // Check if this was a customer trying to log in as admin
        const isCustomerEmail = registeredCustomers.some(
          (c) => c.email.trim().toLowerCase() === normalizedEmail
        );
        if (isCustomerEmail) {
          return {
            success: false,
            error: 'This account is registered as a Customer. Please select Customer role to sign in.',
          };
        }
        return {
          success: false,
          error: 'Invalid Admin email or password. Please verify your credentials.',
        };
      }

      if (password !== DEFAULT_ADMIN.password) {
        return {
          success: false,
          error: 'Invalid Admin password. Please try again.',
        };
      }

      const adminUser = {
        id: DEFAULT_ADMIN.id,
        name: DEFAULT_ADMIN.name,
        email: DEFAULT_ADMIN.email,
        role: 'Admin',
      };

      setCurrentUser(adminUser);
      setUserRole('Admin');
      setIsAuthenticated(true);

      try {
        await AsyncStorage.setItem(
          STORAGE_SESSION_KEY,
          JSON.stringify({ user: adminUser, role: 'Admin' })
        );
      } catch (error) {
        console.warn('Error saving session:', error);
      }

      return { success: true };
    }

    // Role is Customer
    if (role === 'Customer') {
      // Check if this is the Admin trying to log in as customer
      if (normalizedEmail === adminNormalizedEmail) {
        return {
          success: false,
          error: 'This email is registered as an Admin account. Please select the Admin role to sign in.',
        };
      }

      const customer = registeredCustomers.find(
        (c) => c.email.trim().toLowerCase() === normalizedEmail
      );

      if (!customer) {
        return {
          success: false,
          error: 'No Customer account found with this email. Please sign up first.',
        };
      }

      if (!verifyPassword(password, customer.passwordHash)) {
        return {
          success: false,
          error: 'Invalid email or password. Please try again.',
        };
      }

      const customerUser = {
        id: customer.id,
        name: customer.name,
        email: customer.email,
        phone: customer.phone,
        address: customer.address || '',
        role: 'Customer',
      };

      setCurrentUser(customerUser);
      setUserRole('Customer');
      setIsAuthenticated(true);

      try {
        await AsyncStorage.setItem(
          STORAGE_SESSION_KEY,
          JSON.stringify({ user: customerUser, role: 'Customer' })
        );
      } catch (error) {
        console.warn('Error saving session:', error);
      }

      return { success: true };
    }

    return {
      success: false,
      error: 'Please select a valid role (Admin or Customer).',
    };
  };

  /**
   * Update Customer Profile.
   * Customer cannot change their role to Admin.
   * Prevents duplicate emails against other registered customers and default Admin.
   */
  const updateCustomerProfile = async ({ name, email, phone, address }) => {
    if (userRole === 'Admin') {
      return { success: false, error: 'Admin profile cannot be updated here.' };
    }
    if (!currentUser) {
      return { success: false, error: 'No active user session found.' };
    }

    const normalizedEmail = email.trim().toLowerCase();
    const adminNormalizedEmail = DEFAULT_ADMIN.email.trim().toLowerCase();

    // Prevent taking the Admin email
    if (normalizedEmail === adminNormalizedEmail) {
      return {
        success: false,
        error: 'This email address is reserved for the Admin account.',
      };
    }

    // Check for duplicate email in other customer accounts
    const emailTaken = registeredCustomers.some(
      (c) => c.id !== currentUser.id && c.email.trim().toLowerCase() === normalizedEmail
    );
    if (emailTaken) {
      return {
        success: false,
        error: 'This email address is already in use by another account.',
      };
    }

    const updatedUser = {
      ...currentUser,
      name: name.trim(),
      email: normalizedEmail,
      phone: phone.trim(),
      address: (address || '').trim(),
      role: 'Customer', // Role is locked to Customer
    };

    // Update in registeredCustomers list (preserving existing passwordHash & createdAt)
    const updatedCustomersList = registeredCustomers.map((c) =>
      c.id === currentUser.id
        ? {
            ...c,
            name: updatedUser.name,
            email: updatedUser.email,
            phone: updatedUser.phone,
            address: updatedUser.address,
            role: 'Customer',
          }
        : c
    );

    setCurrentUser(updatedUser);
    setRegisteredCustomers(updatedCustomersList);

    try {
      await AsyncStorage.setItem(STORAGE_CUSTOMERS_KEY, JSON.stringify(updatedCustomersList));
      await AsyncStorage.setItem(
        STORAGE_SESSION_KEY,
        JSON.stringify({ user: updatedUser, role: 'Customer' })
      );
    } catch (err) {
      console.warn('Error saving updated profile to AsyncStorage:', err);
    }

    return {
      success: true,
      message: 'Profile updated successfully!',
      user: updatedUser,
    };
  };

  /**
   * Delete Customer Profile.
   * Removes ONLY the active Customer's account and profile data from storage.
   * Never deletes the default Admin or unrelated accounts.
   */
  const deleteCustomerProfile = async () => {
    if (userRole === 'Admin') {
      return {
        success: false,
        error: 'Default Admin account cannot be deleted.',
      };
    }
    if (!currentUser || !currentUser.id) {
      return {
        success: false,
        error: 'No active customer session to delete.',
      };
    }

    const customerIdToDelete = currentUser.id;

    // Filter out ONLY the current customer
    const updatedCustomersList = registeredCustomers.filter(
      (c) => c.id !== customerIdToDelete
    );

    setRegisteredCustomers(updatedCustomersList);
    setCurrentUser(null);
    setUserRole(null);
    setIsAuthenticated(false);

    try {
      await AsyncStorage.setItem(STORAGE_CUSTOMERS_KEY, JSON.stringify(updatedCustomersList));
      await AsyncStorage.removeItem(STORAGE_SESSION_KEY);
      // Clean up favorites storage for this customer
      await AsyncStorage.removeItem(`@grocery_favorites_${customerIdToDelete}`);
    } catch (err) {
      console.warn('Error deleting customer account from storage:', err);
    }

    return {
      success: true,
      message: 'Your account has been deleted successfully.',
    };
  };

  /**
   * Log out: clears the session and returns to Home.
   */
  const logout = async () => {
    setCurrentUser(null);
    setUserRole(null);
    setIsAuthenticated(false);

    try {
      await AsyncStorage.removeItem(STORAGE_SESSION_KEY);
    } catch (error) {
      console.warn('Error removing session:', error);
    }
  };

  /**
   * Quick role switch helper for testing
   */
  const switchRole = (newRole) => {
    setUserRole(newRole);
    if (currentUser) {
      setCurrentUser({ ...currentUser, role: newRole });
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userRole,
        isAuthenticated,
        isLoading,
        registeredCustomers,
        registerCustomer,
        updateCustomerProfile,
        deleteCustomerProfile,
        login,
        logout,
        switchRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
