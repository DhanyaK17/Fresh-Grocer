import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const CartContext = createContext();

const CART_STORAGE_KEY = '@grocery_cart_items';

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load saved cart from AsyncStorage on startup
  useEffect(() => {
    const loadCart = async () => {
      try {
        const stored = await AsyncStorage.getItem(CART_STORAGE_KEY);
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed)) {
            setCartItems(parsed);
          }
        }
      } catch (err) {
        console.warn('Error reading cart from storage:', err);
      } finally {
        setIsLoaded(true);
      }
    };

    loadCart();
  }, []);

  // Helper to persist cart items
  const persistCart = async (items) => {
    try {
      await AsyncStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
    } catch (err) {
      console.warn('Error saving cart to storage:', err);
    }
  };

  /**
   * Add product to cart.
   * If product is already in cart, increases its quantity.
   * Otherwise adds as a new entry with quantity = 1 (or specified quantity).
   * Prevents duplicate entries with the same product ID.
   */
  const addToCart = (product, quantityToAdd = 1) => {
    if (!product || !product.id || quantityToAdd <= 0) return;

    setCartItems((prevItems) => {
      const existingIndex = prevItems.findIndex((item) => item.id === product.id);
      let updated;

      if (existingIndex > -1) {
        // Product already in cart -> increase quantity
        updated = prevItems.map((item, idx) =>
          idx === existingIndex
            ? { ...item, quantity: item.quantity + quantityToAdd }
            : item
        );
      } else {
        // New item entry
        updated = [
          ...prevItems,
          {
            id: product.id,
            product,
            quantity: quantityToAdd,
          },
        ];
      }

      persistCart(updated);
      return updated;
    });
  };

  /**
   * Add multiple products to cart at once (e.g. Add All from Favorites).
   * Adds 1 unit of each product; increments existing items without duplication.
   */
  const addMultipleToCart = (productsList) => {
    if (!Array.isArray(productsList) || productsList.length === 0) return;

    setCartItems((prevItems) => {
      let updated = [...prevItems];
      productsList.forEach((product) => {
        if (!product || !product.id) return;
        const existingIndex = updated.findIndex((item) => item.id === product.id);
        if (existingIndex > -1) {
          updated[existingIndex] = {
            ...updated[existingIndex],
            quantity: updated[existingIndex].quantity + 1,
          };
        } else {
          updated.push({
            id: product.id,
            product,
            quantity: 1,
          });
        }
      });
      persistCart(updated);
      return updated;
    });
  };

  /**
   * Remove a product completely from cart.
   */
  const removeFromCart = (productId) => {
    setCartItems((prevItems) => {
      const updated = prevItems.filter((item) => item.id !== productId);
      persistCart(updated);
      return updated;
    });
  };

  /**
   * Update the quantity of a specific item.
   * If newQuantity <= 0, item is removed from cart.
   */
  const updateQuantity = (productId, newQuantity) => {
    if (newQuantity <= 0) {
      removeFromCart(productId);
      return;
    }

    setCartItems((prevItems) => {
      const updated = prevItems.map((item) =>
        item.id === productId ? { ...item, quantity: Math.floor(newQuantity) } : item
      );
      persistCart(updated);
      return updated;
    });
  };

  /**
   * Increase quantity by 1.
   */
  const increaseQuantity = (productId) => {
    const current = getItemQuantity(productId);
    updateQuantity(productId, current + 1);
  };

  /**
   * Decrease quantity by 1.
   * Quantity never goes below 1 through controls (returns false if already at 1).
   */
  const decreaseQuantity = (productId) => {
    const current = getItemQuantity(productId);
    if (current > 1) {
      updateQuantity(productId, current - 1);
      return true;
    }
    return false;
  };

  /**
   * Clear all items in cart.
   */
  const clearCart = () => {
    setCartItems([]);
    persistCart([]);
  };

  /**
   * Returns current quantity for a given product ID.
   */
  const getItemQuantity = (productId) => {
    const item = cartItems.find((i) => i.id === productId);
    return item ? item.quantity : 0;
  };

  /**
   * Checks if product exists in cart.
   */
  const isInCart = (productId) => {
    return cartItems.some((i) => i.id === productId);
  };

  // Total quantity of all items in cart (badge count)
  const totalItemCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  // Subtotal in ₹ (sum of unit price × quantity)
  const subtotal = cartItems.reduce(
    (sum, item) => sum + (item.product?.price || 0) * item.quantity,
    0
  );

  // Delivery charge (₹40 if subtotal < 500, FREE if >= 500, 0 if empty)
  const deliveryFee = cartItems.length === 0 ? 0 : subtotal >= 500 ? 0 : 40;

  // Final total in ₹
  const finalTotal = subtotal + deliveryFee;

  return (
    <CartContext.Provider
      value={{
        cartItems,
        isLoaded,
        addToCart,
        addMultipleToCart,
        removeFromCart,
        updateQuantity,
        increaseQuantity,
        decreaseQuantity,
        clearCart,
        getItemQuantity,
        isInCart,
        totalItemCount,
        subtotal,
        deliveryFee,
        finalTotal,
        totalAmount: finalTotal,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
