import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from './AuthContext';
import { PRODUCTS } from '../data/products';

const FavoritesContext = createContext();

export const FavoritesProvider = ({ children }) => {
  const { userRole, currentUser } = useAuth();
  const [favorites, setFavorites] = useState([]);
  const [isLoaded, setIsLoaded] = useState(false);

  // Storage key is scoped to the user or default customer
  const storageKey = `@grocery_favorites_${currentUser?.id || 'guest_customer'}`;

  // Load favorites whenever active customer changes
  useEffect(() => {
    const loadFavorites = async () => {
      // Admin accounts do not possess or load Customer favorites
      if (userRole === 'Admin') {
        setFavorites([]);
        setIsLoaded(true);
        return;
      }

      try {
        const stored = await AsyncStorage.getItem(storageKey);
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed)) {
            setFavorites(parsed);
          }
        } else {
          setFavorites([]);
        }
      } catch (err) {
        console.warn('Error reading favorites from storage:', err);
      } finally {
        setIsLoaded(true);
      }
    };

    loadFavorites();
  }, [userRole, currentUser?.id, storageKey]);

  // Helper to persist favorites
  const persistFavorites = async (items) => {
    if (userRole === 'Admin') return;
    try {
      await AsyncStorage.setItem(storageKey, JSON.stringify(items));
    } catch (err) {
      console.warn('Error saving favorites to storage:', err);
    }
  };

  /**
   * Check if a product ID is in favorites.
   */
  const isFavorite = (productId) => {
    if (userRole === 'Admin') return false;
    return favorites.some((item) => item.id === productId);
  };

  /**
   * Toggle a product in/out of favorites.
   * Accepts full product object or product ID.
   * Admin cannot modify customer favorites.
   */
  const toggleFavorite = (productOrId) => {
    if (userRole === 'Admin' || !productOrId) return;

    const prodId = typeof productOrId === 'string' ? productOrId : productOrId.id;
    if (!prodId) return;

    const fullProduct =
      typeof productOrId === 'object' && productOrId.name
        ? productOrId
        : PRODUCTS.find((p) => p.id === prodId) || { id: prodId };

    setFavorites((prevFavorites) => {
      const exists = prevFavorites.some((item) => item.id === prodId);
      let updated;
      if (exists) {
        updated = prevFavorites.filter((item) => item.id !== prodId);
      } else {
        updated = [...prevFavorites, fullProduct];
      }
      persistFavorites(updated);
      return updated;
    });
  };

  /**
   * Remove a specific product from favorites.
   */
  const removeFavorite = (productId) => {
    if (userRole === 'Admin' || !productId) return;

    setFavorites((prevFavorites) => {
      const updated = prevFavorites.filter((item) => item.id !== productId);
      persistFavorites(updated);
      return updated;
    });
  };

  /**
   * Clear all favorites.
   */
  const clearFavorites = () => {
    if (userRole === 'Admin') return;
    setFavorites([]);
    persistFavorites([]);
  };

  return (
    <FavoritesContext.Provider
      value={{
        favorites,
        isLoaded,
        isFavorite,
        toggleFavorite,
        removeFavorite,
        clearFavorites,
        favoriteCount: favorites.length,
      }}
    >
      {children}
    </FavoritesContext.Provider>
  );
};

export const useFavorites = () => {
  const context = useContext(FavoritesContext);
  if (!context) {
    throw new Error('useFavorites must be used within a FavoritesProvider');
  }
  return context;
};
