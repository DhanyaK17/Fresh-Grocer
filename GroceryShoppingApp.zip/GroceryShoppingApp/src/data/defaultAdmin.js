/**
 * Default Admin Configuration
 * Predefined demo Admin credentials for frontend mock authentication.
 *
 * NOTE: This is a frontend-only demo without a backend or database.
 * Passwords are not displayed in the UI and are never stored in plain text in AsyncStorage.
 */

export const DEFAULT_ADMIN = {
  id: 'admin-dhanya-01',
  name: 'Dhanya',
  email: 'dhanyakannan276@gmail.com',
  password: 'Dhanzz@12',
  role: 'Admin',
};
