import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { AdminDrawerNavigator } from './DrawerNavigator';
import HomeScreen from '../screens/HomeScreen';
import ProductsScreen from '../screens/ProductsScreen';
import CartScreen from '../screens/CartScreen';

const Stack = createNativeStackNavigator();

export default function AdminNavigator() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: '#344E41',
        },
        headerTintColor: '#FFFFFF',
        headerTitleStyle: {
          fontWeight: 'bold',
          color: '#FFFFFF',
        },
      }}
    >
      {/* Root Drawer (contains Admin Tab Navigator and Admin Drawer screens) */}
      <Stack.Screen
        name="AdminDrawer"
        component={AdminDrawerNavigator}
        options={{ headerShown: false }}
      />

      {/* Admin Allowed Stack Navigation Screens */}
      <Stack.Screen
        name="HomeScreen"
        component={HomeScreen}
        options={{ title: 'Admin Home' }}
      />
      <Stack.Screen
        name="Products"
        component={ProductsScreen}
        options={{ title: 'Products Catalog' }}
      />
      {/* Guarded route: If Admin attempts to navigate to Cart directly, CartScreen intercepts and redirects to Products */}
      <Stack.Screen
        name="Cart"
        component={CartScreen}
        options={{ title: 'Access Restricted' }}
      />

      {/* Note: ProductDetails, Favorites, Profile, and EditProfile are Customer-only screens
          and are deliberately excluded to prevent unauthorized navigation. */}
    </Stack.Navigator>
  );
}
