import React from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { useAuth } from '../context/AuthContext';
import AuthNavigator from './AuthNavigator';
import CustomerNavigator from './CustomerNavigator';
import AdminNavigator from './AdminNavigator';

export default function AppNavigator() {
  const { isAuthenticated, userRole, isLoading } = useAuth();

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#344E41" />
      </View>
    );
  }

  // If user is not authenticated, show the authentication stack (Home / SignIn / SignUp)
  if (!isAuthenticated) {
    return <AuthNavigator />;
  }

  // If logged in as Admin, mount AdminNavigator only (Customer-only screens are omitted)
  if (userRole === 'Admin') {
    return <AdminNavigator />;
  }

  // Otherwise, mount CustomerNavigator (Student means Customer)
  return <CustomerNavigator />;
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F8F5EC',
  },
});
