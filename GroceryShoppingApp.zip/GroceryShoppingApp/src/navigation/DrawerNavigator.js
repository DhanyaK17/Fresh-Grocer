import React from 'react';
import { View, Text, StyleSheet, Alert, Platform } from 'react-native';
import {
  createDrawerNavigator,
  DrawerContentScrollView,
  DrawerItemList,
  DrawerItem,
} from '@react-navigation/drawer';
import { Ionicons } from '@expo/vector-icons';

import { CustomerTabNavigator, AdminTabNavigator } from './TabNavigator';
import ProductsScreen from '../screens/ProductsScreen';
import FavoritesScreen from '../screens/FavoritesScreen';
import CartScreen from '../screens/CartScreen';
import ProfileScreen from '../screens/ProfileScreen';
import EditProfileScreen from '../screens/EditProfileScreen';
import DeleteProfileScreen from '../screens/DeleteProfileScreen';
import { useAuth } from '../context/AuthContext';
import { COLORS } from '../utils/theme';

const Drawer = createDrawerNavigator();

function CustomDrawerContent(props) {
  const { userRole, logout, currentUser } = useAuth();
  const isCustomer = userRole === 'Customer';

  const getInitials = (name) => {
    if (!name || typeof name !== 'string') return isCustomer ? 'C' : 'A';
    const parts = name.trim().split(' ').filter(Boolean);
    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  };

  const handleLogout = () => {
    Alert.alert(
      'Log Out',
      'Are you sure you want to log out of your session?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Log Out',
          style: 'destructive',
          onPress: () => {
            props.navigation.closeDrawer();
            logout();
          },
        },
      ]
    );
  };

  return (
    <DrawerContentScrollView {...props} contentContainerStyle={styles.drawerContainer}>
      {/* Drawer Brand Header */}
      <View style={styles.header}>
        <View style={styles.brandRow}>
          <View style={styles.brandLogoBox}>
            <Ionicons name="basket" size={20} color="#FFFFFF" />
          </View>
          <Text style={styles.brandTitle}>FreshGrocer</Text>
        </View>

        <View style={styles.userInfoRow}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {getInitials(currentUser?.name)}
            </Text>
          </View>
          <View style={styles.userTextCol}>
            <Text style={styles.userName} numberOfLines={1}>
              {currentUser?.name || (isCustomer ? 'Customer Account' : 'Dhanya (Admin)')}
            </Text>
            <Text style={styles.userEmail} numberOfLines={1}>
              {currentUser?.email || (isCustomer ? 'student@groceryshop.com' : 'dhanyakannan276@gmail.com')}
            </Text>
            <View style={[styles.roleBadge, isCustomer ? styles.customerRoleBadge : styles.adminRoleBadge]}>
              <Ionicons
                name={isCustomer ? 'person' : 'shield-checkmark'}
                size={11}
                color={isCustomer ? '#344E41' : '#2A5D74'}
                style={{ marginRight: 4 }}
              />
              <Text style={[styles.roleBadgeText, isCustomer ? styles.customerRoleText : styles.adminRoleText]}>
                {userRole || 'Customer'}
              </Text>
            </View>
          </View>
        </View>
      </View>

      {/* Drawer Nav Items */}
      <View style={styles.drawerList}>
        <DrawerItemList {...props} />
      </View>

      {/* Drawer Footer with Logout */}
      <View style={styles.footer}>
        <DrawerItem
          label="Logout"
          icon={({ color, size }) => (
            <Ionicons name="log-out-outline" size={size} color="#D32F2F" />
          )}
          labelStyle={styles.logoutLabel}
          style={styles.logoutItem}
          onPress={handleLogout}
        />
        <Text style={styles.versionText}>GroceryShop v1.0.0 • Mobile UI</Text>
      </View>
    </DrawerContentScrollView>
  );
}

const commonDrawerScreenOptions = {
  drawerActiveTintColor: '#344E41',
  drawerActiveBackgroundColor: '#EBF0E6',
  drawerInactiveTintColor: '#26352B',
  headerTintColor: '#FFFFFF',
  headerStyle: {
    backgroundColor: '#344E41',
    elevation: 0,
    shadowOpacity: 0,
    borderBottomWidth: 1,
    borderBottomColor: '#2C4237',
  },
  headerTitleStyle: {
    fontWeight: '800',
    fontSize: 18,
    color: '#FFFFFF',
  },
  drawerLabelStyle: {
    fontWeight: '600',
    fontSize: 14,
    marginLeft: -6,
  },
  drawerItemStyle: {
    borderRadius: 12,
    marginHorizontal: 10,
    marginVertical: 2,
    paddingHorizontal: 8,
  },
};

// Customer Drawer: Home, Products, Favorites, Cart, Profile, Edit Profile, Delete Profile, Logout
export function CustomerDrawerNavigator() {
  const { deleteCustomerProfile } = useAuth();

  const promptDeleteProfileFromDrawer = (navigation) => {
    navigation.closeDrawer();
    Alert.alert(
      'Delete Profile',
      'Are you sure you want to delete your profile? This action cannot be undone.',
      [
        {
          text: 'Cancel',
          style: 'cancel',
          onPress: () => {
            // Cancel leaves profile and session unchanged
          },
        },
        {
          text: 'Delete Profile',
          style: 'destructive',
          onPress: async () => {
            const result = await deleteCustomerProfile();
            if (result.success) {
              Alert.alert(
                'Account Deleted',
                result.message || 'Your account has been deleted successfully.'
              );
            } else {
              Alert.alert('Error', result.error || 'Failed to delete account.');
            }
          },
        },
      ]
    );
  };

  return (
    <Drawer.Navigator
      drawerContent={(props) => <CustomDrawerContent {...props} />}
      screenOptions={commonDrawerScreenOptions}
    >
      <Drawer.Screen
        name="HomeDrawer"
        component={CustomerTabNavigator}
        options={{
          title: 'Home',
          headerShown: false,
          drawerIcon: ({ color, size }) => (
            <Ionicons name="home-outline" size={size} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Products"
        component={ProductsScreen}
        options={{
          title: 'Products',
          drawerIcon: ({ color, size }) => (
            <Ionicons name="grid-outline" size={size} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Favorites"
        component={FavoritesScreen}
        options={{
          title: 'Favorites',
          drawerIcon: ({ color, size }) => (
            <Ionicons name="heart-outline" size={size} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Cart"
        component={CartScreen}
        options={{
          title: 'Cart',
          drawerIcon: ({ color, size }) => (
            <Ionicons name="cart-outline" size={size} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Profile"
        component={ProfileScreen}
        options={{
          title: 'Profile',
          drawerIcon: ({ color, size }) => (
            <Ionicons name="person-outline" size={size} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="EditProfile"
        component={EditProfileScreen}
        options={{
          title: 'Edit Profile',
          drawerIcon: ({ color, size }) => (
            <Ionicons name="create-outline" size={size} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="DeleteProfile"
        component={DeleteProfileScreen}
        listeners={({ navigation }) => ({
          drawerItemPress: (e) => {
            e.preventDefault();
            promptDeleteProfileFromDrawer(navigation);
          },
        })}
        options={{
          title: 'Delete Profile',
          drawerIcon: ({ color, size }) => (
            <Ionicons name="trash-outline" size={size} color="#D32F2F" />
          ),
          drawerLabelStyle: {
            color: '#D32F2F',
            fontWeight: '700',
            fontSize: 14,
            marginLeft: -6,
          },
          drawerItemStyle: {
            borderRadius: 12,
            marginHorizontal: 10,
            marginVertical: 2,
            paddingHorizontal: 8,
            backgroundColor: '#FFEBEE',
          },
        }}
      />
    </Drawer.Navigator>
  );
}

// Admin Drawer: Home, Products, Logout (Cart and Customer-only items omitted)
export function AdminDrawerNavigator() {
  return (
    <Drawer.Navigator
      drawerContent={(props) => <CustomDrawerContent {...props} />}
      screenOptions={commonDrawerScreenOptions}
    >
      <Drawer.Screen
        name="AdminHomeDrawer"
        component={AdminTabNavigator}
        options={{
          title: 'Home',
          headerShown: false,
          drawerIcon: ({ color, size }) => (
            <Ionicons name="home-outline" size={size} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Products"
        component={ProductsScreen}
        options={{
          title: 'Products',
          drawerIcon: ({ color, size }) => (
            <Ionicons name="grid-outline" size={size} color={color} />
          ),
        }}
      />
    </Drawer.Navigator>
  );
}

export default function DrawerNavigator({ role = 'Customer' }) {
  if (role === 'Admin') {
    return <AdminDrawerNavigator />;
  }
  return <CustomerDrawerNavigator />;
}

const styles = StyleSheet.create({
  drawerContainer: {
    flex: 1,
    paddingTop: 0,
    backgroundColor: '#F8F5EC',
  },
  header: {
    padding: 20,
    paddingTop: Platform.OS === 'android' ? 36 : 24,
    backgroundColor: '#344E41',
    marginBottom: 8,
  },
  brandRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    gap: 8,
  },
  brandLogoBox: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  brandTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.5,
  },
  userInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: '#D97757',
    borderWidth: 2,
    borderColor: '#A3B18A',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  avatarText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  userTextCol: {
    flex: 1,
  },
  userName: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  userEmail: {
    color: '#A3B18A',
    fontSize: 12,
    marginTop: 1,
  },
  roleBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 12,
    marginTop: 6,
  },
  customerRoleBadge: {
    backgroundColor: '#EBF0E6',
  },
  adminRoleBadge: {
    backgroundColor: '#EBF2F5',
  },
  roleBadgeText: {
    fontSize: 11,
    fontWeight: '700',
  },
  customerRoleText: {
    color: '#344E41',
  },
  adminRoleText: {
    color: '#2A5D74',
  },
  drawerList: {
    flex: 1,
    paddingTop: 4,
  },
  footer: {
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: '#EDE8DB',
    backgroundColor: '#F8F5EC',
  },
  logoutItem: {
    borderRadius: 12,
    marginHorizontal: 10,
    paddingHorizontal: 8,
  },
  logoutLabel: {
    color: '#D32F2F',
    fontWeight: 'bold',
    fontSize: 14,
    marginLeft: -6,
  },
  versionText: {
    fontSize: 11,
    color: '#9E9E9E',
    textAlign: 'center',
    marginTop: 6,
  },
});
