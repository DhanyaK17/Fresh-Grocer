import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { DrawerToggleButton } from '@react-navigation/drawer';
import { Ionicons } from '@expo/vector-icons';
import { Platform } from 'react-native';

import HomeScreen from '../screens/HomeScreen';
import ProductsScreen from '../screens/ProductsScreen';
import FavoritesScreen from '../screens/FavoritesScreen';
import CartScreen from '../screens/CartScreen';
import ProfileScreen from '../screens/ProfileScreen';
import { useCart } from '../context/CartContext';
import { COLORS } from '../utils/theme';

const Tab = createBottomTabNavigator();

const commonScreenOptions = {
  tabBarActiveTintColor: COLORS.forestGreen,
  tabBarInactiveTintColor: COLORS.textMuted,
  tabBarStyle: {
    backgroundColor: '#FFFFFF',
    borderTopColor: COLORS.cardBorder,
    borderTopWidth: 1,
    height: Platform.OS === 'android' ? 62 : 60,
    paddingBottom: Platform.OS === 'android' ? 8 : 6,
    paddingTop: 6,
    elevation: 8,
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  tabBarLabelStyle: {
    fontSize: 11,
    fontWeight: '600',
    marginTop: -2,
  },
  headerStyle: {
    backgroundColor: COLORS.forestGreen,
    elevation: 0,
    shadowOpacity: 0,
    borderBottomWidth: 1,
    borderBottomColor: '#2C4237',
  },
  headerTintColor: '#FFFFFF',
  headerTitleStyle: {
    fontWeight: '800',
    fontSize: 18,
    color: '#FFFFFF',
  },
  headerLeft: () => <DrawerToggleButton tintColor="#FFFFFF" />,
};

// Customer Tabs: Home, Products, Favorites, Cart, Profile
export function CustomerTabNavigator() {
  const { cartCount } = useCart();

  return (
    <Tab.Navigator screenOptions={commonScreenOptions}>
      <Tab.Screen
        name="HomeTab"
        component={HomeScreen}
        options={{
          title: 'Home',
          tabBarLabel: 'Home',
          tabBarIcon: ({ color, size, focused }) => (
            <Ionicons name={focused ? 'home' : 'home-outline'} size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="ProductsTab"
        component={ProductsScreen}
        options={{
          title: 'Products',
          tabBarLabel: 'Products',
          tabBarIcon: ({ color, size, focused }) => (
            <Ionicons name={focused ? 'grid' : 'grid-outline'} size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="FavoritesTab"
        component={FavoritesScreen}
        options={{
          title: 'Favorites',
          tabBarLabel: 'Favorites',
          tabBarIcon: ({ color, size, focused }) => (
            <Ionicons name={focused ? 'heart' : 'heart-outline'} size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="CartTab"
        component={CartScreen}
        options={{
          title: 'Cart',
          tabBarLabel: 'Cart',
          tabBarBadge: cartCount > 0 ? cartCount : undefined,
          tabBarBadgeStyle: {
            backgroundColor: COLORS.terracotta,
            color: '#FFFFFF',
            fontSize: 10,
            fontWeight: 'bold',
            lineHeight: 14,
            height: 18,
            minWidth: 18,
            borderRadius: 9,
          },
          tabBarIcon: ({ color, size, focused }) => (
            <Ionicons name={focused ? 'cart' : 'cart-outline'} size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="ProfileTab"
        component={ProfileScreen}
        options={{
          title: 'Profile',
          tabBarLabel: 'Profile',
          tabBarIcon: ({ color, size, focused }) => (
            <Ionicons name={focused ? 'person' : 'person-outline'} size={size} color={color} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

// Admin Tabs: Home and Products only (Cart and other customer-only tabs are removed)
export function AdminTabNavigator() {
  return (
    <Tab.Navigator screenOptions={commonScreenOptions}>
      <Tab.Screen
        name="AdminHomeTab"
        component={HomeScreen}
        options={{
          title: 'Admin Home',
          tabBarLabel: 'Home',
          tabBarIcon: ({ color, size, focused }) => (
            <Ionicons name={focused ? 'home' : 'home-outline'} size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="AdminProductsTab"
        component={ProductsScreen}
        options={{
          title: 'Products Catalog',
          tabBarLabel: 'Products',
          tabBarIcon: ({ color, size, focused }) => (
            <Ionicons name={focused ? 'grid' : 'grid-outline'} size={size} color={color} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

export default function TabNavigator({ role = 'Customer' }) {
  if (role === 'Admin') {
    return <AdminTabNavigator />;
  }
  return <CustomerTabNavigator />;
}
