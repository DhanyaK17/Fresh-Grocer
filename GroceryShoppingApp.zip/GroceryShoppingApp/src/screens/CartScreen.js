import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Image,
  SafeAreaView,
  StatusBar,
  Alert,
  Platform,
  ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

export default function CartScreen({ navigation }) {
  const { userRole } = useAuth();
  const {
    cartItems,
    increaseQuantity,
    decreaseQuantity,
    removeFromCart,
    clearCart,
    totalItemCount,
    subtotal,
    deliveryFee,
    finalTotal,
  } = useCart();

  const [toastMessage, setToastMessage] = useState('');

  // Role-Based Route Protection: My Cart is available only to Customers
  React.useEffect(() => {
    if (userRole === 'Admin') {
      Alert.alert(
        'Access Restricted',
        'My Cart is available only to Customer accounts. Redirecting to Products catalog...'
      );
      navigation.navigate('Products');
    }
  }, [userRole, navigation]);

  if (userRole === 'Admin') {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.restrictedContainer}>
          <View style={styles.restrictedIconBox}>
            <Ionicons name="lock-closed" size={48} color="#C62828" />
          </View>
          <Text style={styles.restrictedTitle}>Customer-Only Screen</Text>
          <Text style={styles.restrictedSubtitle}>
            My Cart is restricted to Customer shoppers. Store Administrators manage store catalog and products.
          </Text>
          <TouchableOpacity
            style={styles.backHomeBtn}
            onPress={() => navigation.navigate('Products')}
            activeOpacity={0.8}
          >
            <Ionicons name="arrow-back" size={18} color="#FFFFFF" />
            <Text style={styles.backHomeBtnText}>Go to Products Catalog</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 2200);
  };

  // Decrement handler: keeps at 1 or asks for confirmation before removing
  const handleDecrease = (item) => {
    if (item.quantity > 1) {
      decreaseQuantity(item.id);
    } else {
      Alert.alert(
        'Remove Item',
        `Do you want to remove ${item.product?.name || 'this item'} from your cart?`,
        [
          { text: 'Keep in Cart', style: 'cancel' },
          {
            text: 'Remove',
            style: 'destructive',
            onPress: () => {
              removeFromCart(item.id);
              showToast('Item removed from cart');
            },
          },
        ]
      );
    }
  };

  // Explicit item remove handler
  const handleRemove = (item) => {
    Alert.alert(
      'Remove Product',
      `Remove ${item.product?.name || 'this product'} from your cart?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: () => {
            removeFromCart(item.id);
            showToast('Item removed from cart');
          },
        },
      ]
    );
  };

  // Clear entire cart with confirmation
  const handleClearCart = () => {
    if (cartItems.length === 0) return;

    Alert.alert(
      'Clear Entire Cart',
      `Are you sure you want to remove all ${totalItemCount} items from your shopping cart?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear All',
          style: 'destructive',
          onPress: () => {
            clearCart();
            showToast('Cart cleared');
          },
        },
      ]
    );
  };

  // Demo checkout action
  const handleCheckout = () => {
    if (cartItems.length === 0) {
      Alert.alert(
        'Cart is Empty',
        'Please add grocery items to your cart before proceeding to checkout.',
        [{ text: 'Browse Products', onPress: () => navigation.navigate('Products') }]
      );
      return;
    }

    Alert.alert(
      'Confirm Demo Checkout',
      `Total Payable: ₹${finalTotal}\n\n• Subtotal: ₹${subtotal}\n• Delivery Fee: ${
        deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`
      }\n• Total Items: ${totalItemCount}\n\nNote: This is a frontend-only demo. No real payment or backend transaction will occur.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Place Demo Order',
          onPress: () => {
            Alert.alert(
              'Demo Order Placed!',
              `Thank you for testing the Grocery Shop demo! Your demo order of ₹${finalTotal} has been simulated successfully. No actual payment was charged.`,
              [
                {
                  text: 'Continue Shopping',
                  onPress: () => {
                    clearCart();
                    navigation.navigate('Products');
                  },
                },
              ]
            );
          },
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor="#344E41" />

      {/* Screen Header */}
      <View style={styles.header}>
        <View style={styles.headerTitles}>
          <Text style={styles.title}>My Cart</Text>
          <Text style={styles.subtitle}>
            {cartItems.length === 0
              ? 'Your basket is empty'
              : `${totalItemCount} ${totalItemCount === 1 ? 'item' : 'items'} in your basket`}
          </Text>
        </View>

        {cartItems.length > 0 ? (
          <TouchableOpacity
            style={styles.clearCartBtn}
            onPress={handleClearCart}
            activeOpacity={0.7}
          >
            <Ionicons name="trash-outline" size={16} color="#FFFFFF" />
            <Text style={styles.clearCartText}>Clear Cart</Text>
          </TouchableOpacity>
        ) : null}
      </View>

      {/* Toast Notification */}
      {toastMessage ? (
        <View style={styles.toast}>
          <Ionicons name="checkmark-circle" size={18} color="#FFFFFF" />
          <Text style={styles.toastText}>{toastMessage}</Text>
        </View>
      ) : null}

      {/* Free Delivery Incentive Header (if cart has items) */}
      {cartItems.length > 0 ? (
        <View
          style={[
            styles.deliveryBanner,
            deliveryFee === 0 ? styles.freeDeliveryBanner : styles.paidDeliveryBanner,
          ]}
        >
          <Ionicons
            name={deliveryFee === 0 ? 'sparkles' : 'bicycle'}
            size={18}
            color={deliveryFee === 0 ? '#344E41' : '#D97757'}
          />
          <Text
            style={[
              styles.deliveryBannerText,
              deliveryFee === 0
                ? styles.freeDeliveryBannerText
                : styles.paidDeliveryBannerText,
            ]}
          >
            {deliveryFee === 0
              ? '🎉 Congratulations! You have unlocked FREE Delivery.'
              : `Add ₹${500 - subtotal} more of groceries for FREE Delivery!`}
          </Text>
        </View>
      ) : null}

      {/* Cart Content */}
      <FlatList
        data={cartItems}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => {
          const itemPrice = item.product?.price || 0;
          const itemSubtotal = itemPrice * item.quantity;

          return (
            <View style={styles.cartCard}>
              {/* Product Thumbnail */}
              <View style={styles.thumbnailContainer}>
                <Image
                  source={{ uri: item.product?.image }}
                  style={styles.thumbnail}
                  resizeMode="cover"
                />
              </View>

              {/* Product Info & Price Breakdown */}
              <View style={styles.cardInfo}>
                <View style={styles.categoryBadgeRow}>
                  <Text style={styles.categoryText}>{item.product?.category}</Text>
                  {item.product?.unit ? (
                    <Text style={styles.unitText}>{item.product.unit}</Text>
                  ) : null}
                </View>

                <Text style={styles.productName} numberOfLines={1}>
                  {item.product?.name}
                </Text>

                {/* Individual item total breakdown: e.g. ₹100 × 2 = ₹200 */}
                <View style={styles.priceCalculationRow}>
                  <Text style={styles.calculationFormula}>
                    ₹{itemPrice} × {item.quantity} ={' '}
                    <Text style={styles.itemSubtotalHighlight}>₹{itemSubtotal}</Text>
                  </Text>
                </View>

                {/* Quantity Controls & Remove Action */}
                <View style={styles.cardControlsRow}>
                  <View style={styles.quantityPill}>
                    <TouchableOpacity
                      style={styles.qtyBtn}
                      onPress={() => handleDecrease(item)}
                      activeOpacity={0.7}
                      hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}
                    >
                      <Ionicons
                        name={item.quantity === 1 ? 'trash-outline' : 'remove'}
                        size={15}
                        color={item.quantity === 1 ? '#C84B31' : '#344E41'}
                      />
                    </TouchableOpacity>

                    <Text style={styles.qtyText}>{item.quantity}</Text>

                    <TouchableOpacity
                      style={styles.qtyBtn}
                      onPress={() => increaseQuantity(item.id)}
                      activeOpacity={0.7}
                      hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}
                    >
                      <Ionicons name="add" size={15} color="#344E41" />
                    </TouchableOpacity>
                  </View>

                  <TouchableOpacity
                    style={styles.removeBtn}
                    onPress={() => handleRemove(item)}
                    activeOpacity={0.7}
                    hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                  >
                    <Ionicons name="trash" size={16} color="#E53935" />
                    <Text style={styles.removeBtnText}>Remove</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          );
        }}
        ListFooterComponent={
          cartItems.length > 0 ? (
            <View style={styles.billSection}>
              <Text style={styles.billSectionTitle}>Bill Summary</Text>

              <View style={styles.billCard}>
                <View style={styles.billRow}>
                  <Text style={styles.billLabel}>Item Subtotal</Text>
                  <Text style={styles.billValue}>₹{subtotal}</Text>
                </View>

                <View style={styles.billRow}>
                  <View style={styles.deliveryLabelRow}>
                    <Text style={styles.billLabel}>Delivery Partner Fee</Text>
                    {deliveryFee === 0 ? (
                      <View style={styles.freePill}>
                        <Text style={styles.freePillText}>FREE</Text>
                      </View>
                    ) : null}
                  </View>
                  <Text
                    style={[
                      styles.billValue,
                      deliveryFee === 0 && styles.freePriceText,
                    ]}
                  >
                    {deliveryFee === 0 ? '₹0' : `₹${deliveryFee}`}
                  </Text>
                </View>

                <View style={styles.billRow}>
                  <Text style={styles.billLabel}>Handling & Packaging</Text>
                  <Text style={[styles.billValue, styles.freePriceText]}>FREE</Text>
                </View>

                <View style={styles.divider} />

                <View style={styles.totalRow}>
                  <View>
                    <Text style={styles.totalTitle}>To Pay</Text>
                    <Text style={styles.inclusiveTaxText}>Inclusive of all taxes</Text>
                  </View>
                  <Text style={styles.totalAmountText}>₹{finalTotal}</Text>
                </View>
              </View>

              {/* Continue Shopping Secondary Button */}
              <TouchableOpacity
                style={styles.continueShoppingBtn}
                onPress={() => navigation.navigate('Products')}
                activeOpacity={0.85}
              >
                <Ionicons name="arrow-back" size={16} color="#344E41" />
                <Text style={styles.continueShoppingBtnText}>
                  Continue Shopping (Add More)
                </Text>
              </TouchableOpacity>
            </View>
          ) : null
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <View style={styles.emptyIconCircle}>
              <Ionicons name="cart-outline" size={60} color="#A3B18A" />
            </View>
            <Text style={styles.emptyTitle}>Your cart is empty</Text>
            <Text style={styles.emptySubtitle}>
              Looks like you haven't added any fresh groceries to your cart yet.
              Explore our farm-fresh catalog and discover daily essentials.
            </Text>
            <TouchableOpacity
              style={styles.exploreProductsBtn}
              onPress={() => navigation.navigate('Products')}
              activeOpacity={0.85}
            >
              <Ionicons name="grid-outline" size={18} color="#FFFFFF" />
              <Text style={styles.exploreProductsBtnText}>Continue Shopping</Text>
            </TouchableOpacity>
          </View>
        }
      />

      {/* Sticky Bottom Checkout Bar (when cart has items) */}
      {cartItems.length > 0 ? (
        <View style={styles.stickyBottomBar}>
          <View style={styles.checkoutPriceBlock}>
            <Text style={styles.stickyTotalLabel}>Total Amount</Text>
            <Text style={styles.stickyTotalValue}>₹{finalTotal}</Text>
          </View>

          <TouchableOpacity
            style={styles.checkoutPrimaryBtn}
            onPress={handleCheckout}
            activeOpacity={0.85}
          >
            <Text style={styles.checkoutPrimaryBtnText}>Proceed to Checkout</Text>
            <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
          </TouchableOpacity>
        </View>
      ) : null}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#344E41',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: Platform.OS === 'android' ? 12 : 10,
    backgroundColor: '#344E41',
    borderBottomWidth: 1,
    borderBottomColor: '#2C4237',
  },
  headerTitles: {
    flex: 1,
  },
  title: {
    fontSize: 22,
    fontWeight: '800',
    color: '#FFFFFF',
  },
  subtitle: {
    fontSize: 12,
    color: '#A3B18A',
    marginTop: 2,
  },
  clearCartBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 8,
    gap: 4,
  },
  clearCartText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  toast: {
    position: 'absolute',
    top: 60,
    left: 20,
    right: 20,
    backgroundColor: '#344E41',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    zIndex: 999,
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
    elevation: 6,
  },
  toastText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },
  deliveryBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 8,
    marginHorizontal: 16,
    marginTop: 10,
    borderRadius: 12,
    gap: 8,
  },
  freeDeliveryBanner: {
    backgroundColor: '#EBF0E6',
    borderColor: '#CCD6BD',
    borderWidth: 1,
  },
  paidDeliveryBanner: {
    backgroundColor: '#FDF6E7',
    borderColor: '#F3DBAC',
    borderWidth: 1,
  },
  deliveryBannerText: {
    fontSize: 12,
    fontWeight: '700',
    flex: 1,
  },
  freeDeliveryBannerText: {
    color: '#344E41',
  },
  paidDeliveryBannerText: {
    color: '#7A541A',
  },
  listContent: {
    padding: 16,
    paddingBottom: 110,
    backgroundColor: '#F8F5EC',
  },
  cartCard: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#EDE8DB',
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 3,
    elevation: 2,
  },
  thumbnailContainer: {
    width: 80,
    height: 80,
    borderRadius: 14,
    backgroundColor: '#FAF7F0',
    overflow: 'hidden',
  },
  thumbnail: {
    width: '100%',
    height: '100%',
  },
  cardInfo: {
    flex: 1,
    marginLeft: 12,
  },
  categoryBadgeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  categoryText: {
    fontSize: 10,
    fontWeight: '700',
    color: '#A3B18A',
    textTransform: 'uppercase',
  },
  unitText: {
    fontSize: 11,
    color: '#56655A',
  },
  productName: {
    fontSize: 15,
    fontWeight: '700',
    color: '#26352B',
    marginVertical: 2,
  },
  priceCalculationRow: {
    marginBottom: 8,
  },
  calculationFormula: {
    fontSize: 13,
    color: '#56655A',
    fontWeight: '500',
  },
  itemSubtotalHighlight: {
    fontSize: 14,
    fontWeight: '800',
    color: '#344E41',
  },
  cardControlsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  quantityPill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FAF7F0',
    borderRadius: 10,
    paddingHorizontal: 4,
    paddingVertical: 2,
    borderWidth: 1,
    borderColor: '#EDE8DB',
  },
  qtyBtn: {
    width: 28,
    height: 28,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
  },
  qtyText: {
    fontSize: 14,
    fontWeight: '800',
    color: '#26352B',
    paddingHorizontal: 10,
  },
  removeBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  removeBtnText: {
    fontSize: 12,
    color: '#C84B31',
    fontWeight: '600',
  },
  billSection: {
    marginTop: 8,
  },
  billSectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#344E41',
    marginBottom: 10,
  },
  billCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: '#EDE8DB',
    marginBottom: 16,
  },
  billRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  billLabel: {
    fontSize: 13,
    color: '#56655A',
  },
  billValue: {
    fontSize: 14,
    fontWeight: '700',
    color: '#26352B',
  },
  deliveryLabelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  freePill: {
    backgroundColor: '#EBF0E6',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
  },
  freePillText: {
    fontSize: 10,
    fontWeight: '800',
    color: '#344E41',
  },
  freePriceText: {
    color: '#344E41',
  },
  divider: {
    height: 1,
    backgroundColor: '#EDE8DB',
    marginVertical: 10,
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  totalTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: '#344E41',
  },
  inclusiveTaxText: {
    fontSize: 11,
    color: '#86968B',
    marginTop: 2,
  },
  totalAmountText: {
    fontSize: 22,
    fontWeight: '800',
    color: '#344E41',
  },
  continueShoppingBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderRadius: 14,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#EDE8DB',
    gap: 8,
  },
  continueShoppingBtnText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#344E41',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
    paddingHorizontal: 32,
  },
  emptyIconCircle: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: '#EBF0E6',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: '#344E41',
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    color: '#56655A',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  exploreProductsBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#D97757',
    paddingVertical: 15,
    paddingHorizontal: 26,
    borderRadius: 14,
    gap: 8,
    shadowColor: '#D97757',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 3,
  },
  exploreProductsBtnText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 15,
  },
  stickyBottomBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#EDE8DB',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: -3 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 8,
    gap: 12,
  },
  checkoutPriceBlock: {
    flex: 1,
  },
  stickyTotalLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: '#56655A',
    textTransform: 'uppercase',
  },
  stickyTotalValue: {
    fontSize: 22,
    fontWeight: '800',
    color: '#344E41',
  },
  checkoutPrimaryBtn: {
    flex: 1.6,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#D97757',
    paddingVertical: 14,
    borderRadius: 14,
    gap: 8,
    shadowColor: '#D97757',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  checkoutPrimaryBtnText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
  },
  restrictedContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
    backgroundColor: '#F8F5EC',
  },
  restrictedIconBox: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#FDF1EE',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  restrictedTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: '#C84B31',
    marginBottom: 8,
    textAlign: 'center',
  },
  restrictedSubtitle: {
    fontSize: 14,
    color: '#56655A',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  backHomeBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#D97757',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    gap: 8,
  },
  backHomeBtnText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 14,
  },
});
