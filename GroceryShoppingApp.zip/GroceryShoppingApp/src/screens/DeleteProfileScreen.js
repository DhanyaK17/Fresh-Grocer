import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';

export default function DeleteProfileScreen({ navigation }) {
  const { currentUser, userRole, deleteCustomerProfile } = useAuth();
  const [isDeleting, setIsDeleting] = useState(false);

  // Guard: Admin account deletion is strictly prohibited
  if (userRole === 'Admin') {
    return (
      <View style={styles.restrictedContainer}>
        <View style={styles.restrictedIconBox}>
          <Ionicons name="shield-alert" size={54} color="#C84B31" />
        </View>
        <Text style={styles.restrictedTitle}>Action Blocked</Text>
        <Text style={styles.restrictedSubtitle}>
          The default Admin account cannot be deleted. This safeguard preserves system
          administration and store management privileges.
        </Text>
        <TouchableOpacity
          style={styles.restrictedBtn}
          onPress={() => navigation.navigate('Products')}
        >
          <Text style={styles.restrictedBtnText}>Return to Catalog</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const promptConfirmation = () => {
    Alert.alert(
      'Delete Profile',
      'Are you sure you want to delete your profile? This action cannot be undone.',
      [
        {
          text: 'Cancel',
          style: 'cancel',
          onPress: () => {
            // Cancel leaves profile and session unchanged
          },
        },
        {
          text: 'Delete Profile',
          style: 'destructive',
          onPress: handleConfirmDelete,
        },
      ]
    );
  };

  const handleConfirmDelete = async () => {
    setIsDeleting(true);
    try {
      const result = await deleteCustomerProfile();
      setIsDeleting(false);

      if (result.success) {
        Alert.alert(
          'Account Deleted',
          result.message || 'Your account and profile have been removed successfully.',
          [{ text: 'OK' }]
        );
        // Session is cleared and AppNavigator automatically switches to AuthNavigator
      } else {
        Alert.alert('Error', result.error || 'Failed to delete account. Please try again.');
      }
    } catch (err) {
      setIsDeleting(false);
      Alert.alert('Error', 'An error occurred while deleting your profile.');
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* Danger Zone Badge */}
      <View style={styles.badge}>
        <Ionicons name="warning-outline" size={16} color="#C84B31" style={{ marginRight: 6 }} />
        <Text style={styles.badgeText}>Permanent Action</Text>
      </View>

      <Text style={styles.title}>Delete Profile</Text>
      <Text style={styles.subtitle}>
        Are you sure you want to delete your profile? This action cannot be undone.
      </Text>

      {/* Target Account Summary */}
      <View style={styles.accountCard}>
        <Text style={styles.accountCardTitle}>Account to be removed:</Text>
        <View style={styles.accountDetails}>
          <Ionicons name="person-circle-outline" size={36} color="#86968B" />
          <View style={styles.accountMeta}>
            <Text style={styles.accountName}>{currentUser?.name || 'Customer'}</Text>
            <Text style={styles.accountEmail}>{currentUser?.email || 'customer@groceryshop.com'}</Text>
          </View>
        </View>
      </View>

      {/* Warning Card */}
      <View style={styles.warningCard}>
        <View style={styles.warningHeader}>
          <Ionicons name="alert-circle" size={24} color="#C84B31" />
          <Text style={styles.warningTitle}>What happens when you delete?</Text>
        </View>

        <View style={styles.bulletItem}>
          <Ionicons name="close-circle" size={16} color="#C84B31" style={styles.bulletIcon} />
          <Text style={styles.bulletText}>
            Your registered Customer account will be permanently removed from this device's storage.
          </Text>
        </View>

        <View style={styles.bulletItem}>
          <Ionicons name="close-circle" size={16} color="#C84B31" style={styles.bulletIcon} />
          <Text style={styles.bulletText}>
            All your saved favorite items and personal profile information will be cleared.
          </Text>
        </View>

        <View style={styles.bulletItem}>
          <Ionicons name="shield-checkmark" size={16} color="#A3B18A" style={styles.bulletIcon} />
          <Text style={styles.bulletText}>
            Other registered customer accounts and the default Admin account remain completely unaffected.
          </Text>
        </View>
      </View>

      {/* Action Buttons */}
      <View style={styles.buttonSection}>
        <TouchableOpacity
          style={[styles.deleteBtn, isDeleting && styles.deleteBtnDisabled]}
          onPress={promptConfirmation}
          disabled={isDeleting}
          activeOpacity={0.8}
        >
          {isDeleting ? (
            <ActivityIndicator color="#FFFFFF" size="small" />
          ) : (
            <>
              <Ionicons name="trash-outline" size={20} color="#FFFFFF" style={{ marginRight: 8 }} />
              <Text style={styles.deleteBtnText}>Delete Profile</Text>
            </>
          )}
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.cancelBtn}
          onPress={() => navigation.goBack()}
          disabled={isDeleting}
          activeOpacity={0.7}
        >
          <Text style={styles.cancelBtnText}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F5EC',
  },
  content: {
    padding: 20,
    alignItems: 'center',
    paddingBottom: 40,
  },
  restrictedContainer: {
    flex: 1,
    padding: 28,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F8F5EC',
  },
  restrictedIconBox: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: '#FDF1EE',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  restrictedTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#C84B31',
    marginBottom: 10,
    textAlign: 'center',
  },
  restrictedSubtitle: {
    fontSize: 14,
    color: '#56655A',
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 24,
  },
  restrictedBtn: {
    backgroundColor: '#344E41',
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 12,
  },
  restrictedBtnText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 15,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FDF1EE',
    borderColor: '#F8CDC3',
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 20,
    marginBottom: 16,
  },
  badgeText: {
    color: '#C84B31',
    fontWeight: 'bold',
    fontSize: 12,
    letterSpacing: 0.5,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#C84B31',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: '#56655A',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  accountCard: {
    width: '100%',
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    borderColor: '#EDE8DB',
    marginBottom: 16,
  },
  accountCardTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: '#56655A',
    textTransform: 'uppercase',
    marginBottom: 10,
  },
  accountDetails: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  accountMeta: {
    marginLeft: 12,
  },
  accountName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#26352B',
  },
  accountEmail: {
    fontSize: 13,
    color: '#56655A',
    marginTop: 2,
  },
  warningCard: {
    width: '100%',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: '#F8CDC3',
    marginBottom: 24,
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 2,
  },
  warningHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    paddingBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#FDF1EE',
  },
  warningTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#C84B31',
    marginLeft: 8,
  },
  bulletItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 10,
  },
  bulletIcon: {
    marginTop: 3,
    marginRight: 8,
  },
  bulletText: {
    flex: 1,
    fontSize: 13,
    color: '#26352B',
    lineHeight: 18,
  },
  buttonSection: {
    width: '100%',
  },
  deleteBtn: {
    flexDirection: 'row',
    width: '100%',
    backgroundColor: '#C84B31',
    paddingVertical: 14,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
    shadowColor: '#C84B31',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 3,
  },
  deleteBtnDisabled: {
    opacity: 0.7,
  },
  deleteBtnText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
  },
  cancelBtn: {
    width: '100%',
    paddingVertical: 14,
    alignItems: 'center',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#EDE8DB',
    backgroundColor: '#FFFFFF',
  },
  cancelBtnText: {
    color: '#56655A',
    fontWeight: '600',
    fontSize: 15,
  },
});
