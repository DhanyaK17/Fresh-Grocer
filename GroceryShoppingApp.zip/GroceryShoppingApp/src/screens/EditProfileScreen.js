import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { validateEditProfileForm } from '../utils/validation';

export default function EditProfileScreen({ navigation }) {
  const { currentUser, userRole, updateCustomerProfile } = useAuth();

  // Guard: Customer-only screen
  if (userRole === 'Admin') {
    return (
      <View style={styles.restrictedContainer}>
        <View style={styles.restrictedIconBox}>
          <Ionicons name="shield-outline" size={54} color="#C62828" />
        </View>
        <Text style={styles.restrictedTitle}>Access Restricted</Text>
        <Text style={styles.restrictedSubtitle}>
          Admin profiles cannot be edited from the customer screen.
        </Text>
        <TouchableOpacity
          style={styles.restrictedBtn}
          onPress={() => navigation.navigate('Products')}
        >
          <Text style={styles.restrictedBtnText}>Back to Products</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // Form State prefilled with existing customer data
  const [name, setName] = useState(currentUser?.name || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [address, setAddress] = useState(currentUser?.address || '');
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Sync state if currentUser changes
  useEffect(() => {
    if (currentUser) {
      setName(currentUser.name || '');
      setEmail(currentUser.email || '');
      setPhone(currentUser.phone || '');
      setAddress(currentUser.address || '');
    }
  }, [currentUser]);

  const handleFieldChange = (field, value) => {
    if (field === 'name') setName(value);
    if (field === 'email') setEmail(value);
    if (field === 'phone') setPhone(value);
    if (field === 'address') setAddress(value);

    // Clear specific field error when user starts editing
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: null, general: null }));
    }
  };

  const handleSave = async () => {
    // 1. Client-side validation
    const validation = validateEditProfileForm({ name, email, phone });
    if (!validation.isValid) {
      setErrors(validation.errors);
      return;
    }

    setIsSubmitting(true);
    setErrors({});

    try {
      // 2. Submit update via AuthContext (persists to AsyncStorage, enforces Customer role, prevents duplicate emails)
      const result = await updateCustomerProfile({
        name,
        email,
        phone,
        address,
      });

      if (!result.success) {
        if (result.error && result.error.toLowerCase().includes('email')) {
          setErrors({ email: result.error });
        } else {
          setErrors({ general: result.error || 'Failed to update profile.' });
        }
        setIsSubmitting(false);
        return;
      }

      // 3. Show success alert and return to Profile screen
      setIsSubmitting(false);
      Alert.alert(
        'Success',
        'Your profile has been updated successfully!',
        [
          {
            text: 'OK',
            onPress: () => navigation.goBack(),
          },
        ]
      );
    } catch (err) {
      setIsSubmitting(false);
      setErrors({ general: 'An unexpected error occurred while saving profile.' });
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.headerBox}>
          <Text style={styles.title}>Edit Profile</Text>
          <Text style={styles.subtitle}>
            Update your personal contact details and delivery address
          </Text>
        </View>

        {errors.general ? (
          <View style={styles.generalErrorBox}>
            <Ionicons name="alert-circle" size={18} color="#D32F2F" />
            <Text style={styles.generalErrorText}>{errors.general}</Text>
          </View>
        ) : null}

        <View style={styles.formCard}>
          {/* Full Name */}
          <View style={styles.inputGroup}>
            <Text style={styles.fieldLabel}>
              Full Name <Text style={styles.requiredAsterisk}>*</Text>
            </Text>
            <View
              style={[
                styles.inputContainer,
                errors.name && styles.inputErrorBorder,
              ]}
            >
              <Ionicons
                name="person-outline"
                size={20}
                color={errors.name ? '#C84B31' : '#344E41'}
                style={styles.inputIcon}
              />
              <TextInput
                style={styles.input}
                value={name}
                onChangeText={(text) => handleFieldChange('name', text)}
                placeholder="Enter your full name"
                placeholderTextColor="#86968B"
                autoCapitalize="words"
              />
            </View>
            {errors.name ? <Text style={styles.errorText}>{errors.name}</Text> : null}
          </View>

          {/* Email Address */}
          <View style={styles.inputGroup}>
            <Text style={styles.fieldLabel}>
              Email Address <Text style={styles.requiredAsterisk}>*</Text>
            </Text>
            <View
              style={[
                styles.inputContainer,
                errors.email && styles.inputErrorBorder,
              ]}
            >
              <Ionicons
                name="mail-outline"
                size={20}
                color={errors.email ? '#C84B31' : '#344E41'}
                style={styles.inputIcon}
              />
              <TextInput
                style={styles.input}
                value={email}
                onChangeText={(text) => handleFieldChange('email', text)}
                placeholder="Enter email address"
                placeholderTextColor="#86968B"
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>
            {errors.email ? <Text style={styles.errorText}>{errors.email}</Text> : null}
          </View>

          {/* Phone Number */}
          <View style={styles.inputGroup}>
            <Text style={styles.fieldLabel}>
              Phone Number <Text style={styles.requiredAsterisk}>*</Text>
            </Text>
            <View
              style={[
                styles.inputContainer,
                errors.phone && styles.inputErrorBorder,
              ]}
            >
              <Ionicons
                name="call-outline"
                size={20}
                color={errors.phone ? '#C84B31' : '#344E41'}
                style={styles.inputIcon}
              />
              <TextInput
                style={styles.input}
                value={phone}
                onChangeText={(text) => handleFieldChange('phone', text)}
                placeholder="Enter 10-digit phone number"
                placeholderTextColor="#86968B"
                keyboardType="phone-pad"
              />
            </View>
            {errors.phone ? <Text style={styles.errorText}>{errors.phone}</Text> : null}
          </View>

          {/* Delivery Address */}
          <View style={styles.inputGroup}>
            <Text style={styles.fieldLabel}>Delivery Address</Text>
            <View style={[styles.inputContainer, styles.textAreaContainer]}>
              <Ionicons
                name="location-outline"
                size={20}
                color="#344E41"
                style={[styles.inputIcon, { marginTop: 10 }]}
              />
              <TextInput
                style={[styles.input, styles.textArea]}
                value={address}
                onChangeText={(text) => handleFieldChange('address', text)}
                placeholder="Enter your street address, apartment, city, and pincode"
                placeholderTextColor="#9E9E9E"
                multiline
                numberOfLines={3}
                textAlignVertical="top"
              />
            </View>
          </View>

          {/* Role: Locked to Customer */}
          <View style={styles.inputGroup}>
            <Text style={styles.fieldLabel}>Account Role</Text>
            <View style={styles.lockedRoleContainer}>
              <Ionicons name="lock-closed" size={18} color="#757575" style={styles.inputIcon} />
              <Text style={styles.lockedRoleText}>Customer (Cannot be changed to Admin)</Text>
            </View>
            <Text style={styles.lockedRoleHint}>
              Role changes are restricted. Admin privileges cannot be self-assigned.
            </Text>
          </View>
        </View>

        {/* Buttons */}
        <View style={styles.buttonSection}>
          <TouchableOpacity
            style={[styles.saveBtn, isSubmitting && styles.saveBtnDisabled]}
            onPress={handleSave}
            disabled={isSubmitting}
            activeOpacity={0.8}
          >
            {isSubmitting ? (
              <ActivityIndicator color="#FFFFFF" size="small" />
            ) : (
              <>
                <Ionicons name="checkmark-circle-outline" size={20} color="#FFFFFF" style={{ marginRight: 8 }} />
                <Text style={styles.saveBtnText}>Save Changes</Text>
              </>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.cancelBtn}
            onPress={() => navigation.goBack()}
            disabled={isSubmitting}
            activeOpacity={0.7}
          >
            <Text style={styles.cancelBtnText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F5EC',
  },
  content: {
    padding: 20,
    paddingBottom: 40,
  },
  restrictedContainer: {
    flex: 1,
    padding: 28,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F8F5EC',
  },
  restrictedIconBox: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: '#FDF1EE',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  restrictedTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#C84B31',
    marginBottom: 10,
    textAlign: 'center',
  },
  restrictedSubtitle: {
    fontSize: 14,
    color: '#56655A',
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 24,
  },
  restrictedBtn: {
    backgroundColor: '#344E41',
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 12,
  },
  restrictedBtnText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 15,
  },
  headerBox: {
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#344E41',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: '#56655A',
  },
  generalErrorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FDF1EE',
    borderWidth: 1,
    borderColor: '#F8CDC3',
    borderRadius: 10,
    padding: 12,
    marginBottom: 16,
  },
  generalErrorText: {
    color: '#C84B31',
    fontSize: 13,
    marginLeft: 8,
    flex: 1,
  },
  formCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: '#EDE8DB',
    marginBottom: 20,
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
  },
  inputGroup: {
    marginBottom: 16,
  },
  fieldLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: '#26352B',
    marginBottom: 6,
  },
  requiredAsterisk: {
    color: '#C84B31',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FAF7F0',
    borderWidth: 1,
    borderColor: '#EDE8DB',
    borderRadius: 12,
    paddingHorizontal: 12,
  },
  textAreaContainer: {
    alignItems: 'flex-start',
    paddingVertical: 4,
  },
  inputErrorBorder: {
    borderColor: '#C84B31',
    backgroundColor: '#FDF1EE',
  },
  inputIcon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    height: 48,
    fontSize: 15,
    color: '#26352B',
  },
  textArea: {
    height: 80,
    paddingTop: 8,
  },
  errorText: {
    color: '#C84B31',
    fontSize: 12,
    marginTop: 4,
    marginLeft: 4,
  },
  lockedRoleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FAF7F0',
    borderWidth: 1,
    borderColor: '#EDE8DB',
    borderRadius: 12,
    paddingHorizontal: 12,
    height: 48,
  },
  lockedRoleText: {
    fontSize: 14,
    color: '#56655A',
    fontWeight: '600',
  },
  lockedRoleHint: {
    fontSize: 11,
    color: '#86968B',
    marginTop: 4,
    marginLeft: 4,
  },
  buttonSection: {
    marginTop: 4,
  },
  saveBtn: {
    flexDirection: 'row',
    backgroundColor: '#D97757',
    paddingVertical: 14,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
    shadowColor: '#D97757',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 3,
  },
  saveBtnDisabled: {
    opacity: 0.7,
  },
  saveBtnText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
  },
  cancelBtn: {
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#EDE8DB',
    backgroundColor: '#FFFFFF',
  },
  cancelBtnText: {
    color: '#56655A',
    fontWeight: '600',
    fontSize: 15,
  },
});
