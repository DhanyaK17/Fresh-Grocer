import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Image,
  SafeAreaView,
  StatusBar,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { useAuth } from '../context/AuthContext';
import { useFavorites } from '../context/FavoritesContext';
import { useCart } from '../context/CartContext';
import CartBadgeIcon from '../components/CartBadgeIcon';

export default function FavoritesScreen({ navigation }) {
  const { userRole } = useAuth();
  const { favorites, removeFavorite, clearFavorites } = useFavorites();
  const { addToCart, addMultipleToCart, getItemQuantity } = useCart();

  const isCustomer = userRole === 'Customer';
  const [toastMessage, setToastMessage] = useState('');

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 2200);
  };

  // Admin access guard
  if (!isCustomer) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.restrictedContainer}>
          <View style={styles.restrictedIconBox}>
            <Ionicons name="lock-closed" size={48} color="#C62828" />
          </View>
          <Text style={styles.restrictedTitle}>Customer-Only Screen</Text>
          <Text style={styles.restrictedSubtitle}>
            Favorites are exclusive to Customer accounts. Store Administrators do not maintain a favorites list.
          </Text>
          <TouchableOpacity
            style={styles.backBtn}
            onPress={() => navigation.goBack()}
            activeOpacity={0.8}
          >
            <Ionicons name="arrow-back" size={18} color="#FFFFFF" />
            <Text style={styles.backBtnText}>Go Back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // Handle Add All to Cart
  const handleAddAllToCart = () => {
    if (favorites.length === 0) return;
    addMultipleToCart(favorites);
    showToast(`Added all ${favorites.length} favorite items to Cart!`);
  };

  // Handle single item add to cart
  const handleAddToCart = (product) => {
    addToCart(product, 1);
    showToast(`Added ${product.name} to Cart`);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor="#344E41" />

      {/* Screen Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>My Favorites</Text>
          <Text style={styles.subtitle}>
            {favorites.length} {favorites.length === 1 ? 'item' : 'items'} saved for quick ordering
          </Text>
        </View>

        <View style={styles.headerRight}>
          <CartBadgeIcon
            onPress={() => navigation.navigate('Cart')}
            tintColor="#FFFFFF"
          />
        </View>
      </View>

      {/* Toast Notification */}
      {toastMessage ? (
        <View style={styles.toast}>
          <Ionicons name="checkmark-circle" size={18} color="#FFFFFF" />
          <Text style={styles.toastText} numberOfLines={1}>
            {toastMessage}
          </Text>
        </View>
      ) : null}

      {/* "Add All to Cart" Quick Action Bar (when favorites exist) */}
      {favorites.length > 0 ? (
        <View style={styles.actionBar}>
          <View style={styles.actionInfo}>
            <Ionicons name="bag-check-outline" size={18} color="#344E41" />
            <Text style={styles.actionInfoText}>
              Ready to buy your favorites?
            </Text>
          </View>

          <TouchableOpacity
            style={styles.addAllBtn}
            onPress={handleAddAllToCart}
            activeOpacity={0.85}
          >
            <Ionicons name="cart" size={16} color="#FFFFFF" />
            <Text style={styles.addAllBtnText}>Add All to Cart</Text>
          </TouchableOpacity>
        </View>
      ) : null}

      {/* Favorites List */}
      <FlatList
        data={favorites}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => {
          const qtyInCart = getItemQuantity(item.id);

          return (
            <TouchableOpacity
              style={styles.favoriteCard}
              onPress={() =>
                navigation.navigate('ProductDetails', {
                  productId: item.id,
                  product: item,
                  title: item.name,
                  price: `₹${item.price}`,
                })
              }
              activeOpacity={0.85}
            >
              {/* Product Thumbnail */}
              <View style={styles.thumbnailContainer}>
                <Image
                  source={{ uri: item.image }}
                  style={styles.thumbnail}
                  resizeMode="cover"
                />
              </View>

              {/* Product Info */}
              <View style={styles.cardDetails}>
                <View style={styles.categoryRow}>
                  <Text style={styles.categoryBadge}>{item.category}</Text>
                  {item.unit ? (
                    <Text style={styles.unitText}>{item.unit}</Text>
                  ) : null}
                </View>

                <Text style={styles.productName} numberOfLines={1}>
                  {item.name}
                </Text>

                <Text style={styles.priceText}>₹{item.price}</Text>
              </View>

              {/* Actions: Add to Cart and Remove Favorite */}
              <View style={styles.actionsColumn}>
                {/* Remove Favorite Button */}
                <TouchableOpacity
                  style={styles.removeBtn}
                  onPress={() => {
                    removeFavorite(item.id);
                    showToast(`Removed from Favorites`);
                  }}
                  hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                  activeOpacity={0.7}
                >
                  <Ionicons name="heart-dislike-outline" size={20} color="#E53935" />
                </TouchableOpacity>

                {/* Add to Cart Button */}
                <TouchableOpacity
                  style={[
                    styles.cardCartBtn,
                    qtyInCart > 0 && styles.cardCartBtnInCart,
                  ]}
                  onPress={() => handleAddToCart(item)}
                  activeOpacity={0.8}
                >
                  <Ionicons
                    name={qtyInCart > 0 ? 'checkmark' : 'add'}
                    size={16}
                    color="#FFFFFF"
                  />
                  {qtyInCart > 0 ? (
                    <Text style={styles.qtyBadgeText}>{qtyInCart}</Text>
                  ) : null}
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          );
        }}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <View style={styles.emptyIconCircle}>
              <Ionicons name="heart-outline" size={54} color="#E91E63" />
            </View>
            <Text style={styles.emptyTitle}>Your Favorites is Empty</Text>
            <Text style={styles.emptySubtitle}>
              You haven't saved any grocery products yet. Tap the heart icon on any product to save it here for fast reordering.
            </Text>
            <TouchableOpacity
              style={styles.shopNowBtn}
              onPress={() => navigation.navigate('Products')}
              activeOpacity={0.85}
            >
              <Ionicons name="grid-outline" size={18} color="#FFFFFF" />
              <Text style={styles.shopNowBtnText}>Continue Shopping</Text>
            </TouchableOpacity>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#344E41',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: Platform.OS === 'android' ? 12 : 10,
    backgroundColor: '#344E41',
    borderBottomWidth: 1,
    borderBottomColor: '#2C4237',
  },
  title: {
    fontSize: 22,
    fontWeight: '800',
    color: '#FFFFFF',
  },
  subtitle: {
    fontSize: 12,
    color: '#A3B18A',
    marginTop: 2,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  toast: {
    position: 'absolute',
    top: 60,
    left: 20,
    right: 20,
    backgroundColor: '#344E41',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    zIndex: 999,
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
    elevation: 6,
  },
  toastText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },
  actionBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#EBF0E6',
    marginHorizontal: 16,
    marginTop: 12,
    marginBottom: 4,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#CCD6BD',
  },
  actionInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flex: 1,
  },
  actionInfoText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#344E41',
  },
  addAllBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#D97757',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
    gap: 6,
    shadowColor: '#D97757',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 2,
  },
  addAllBtnText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '700',
  },
  listContent: {
    padding: 16,
    paddingBottom: 40,
    backgroundColor: '#F8F5EC',
  },
  favoriteCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#EDE8DB',
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 3,
    elevation: 2,
  },
  thumbnailContainer: {
    width: 72,
    height: 72,
    borderRadius: 12,
    backgroundColor: '#FAF7F0',
    overflow: 'hidden',
  },
  thumbnail: {
    width: '100%',
    height: '100%',
  },
  cardDetails: {
    flex: 1,
    marginLeft: 12,
    marginRight: 8,
  },
  categoryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 2,
  },
  categoryBadge: {
    fontSize: 10,
    fontWeight: '700',
    color: '#A3B18A',
    textTransform: 'uppercase',
  },
  unitText: {
    fontSize: 11,
    color: '#56655A',
  },
  productName: {
    fontSize: 15,
    fontWeight: '700',
    color: '#26352B',
    marginVertical: 2,
  },
  priceText: {
    fontSize: 16,
    fontWeight: '800',
    color: '#344E41',
  },
  actionsColumn: {
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },
  removeBtn: {
    padding: 4,
  },
  cardCartBtn: {
    backgroundColor: '#D97757',
    width: 34,
    height: 34,
    borderRadius: 10,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#D97757',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
  },
  cardCartBtnInCart: {
    backgroundColor: '#C25E3E',
    width: 44,
    paddingHorizontal: 4,
    gap: 2,
  },
  qtyBadgeText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: 'bold',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 70,
    paddingHorizontal: 30,
  },
  emptyIconCircle: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: '#FBECE8',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: '#344E41',
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    color: '#56655A',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  shopNowBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#D97757',
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 14,
    gap: 8,
    shadowColor: '#D97757',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 3,
  },
  shopNowBtnText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 15,
  },
  restrictedContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
    backgroundColor: '#F8F5EC',
  },
  restrictedIconBox: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#FDF1EE',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  restrictedTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: '#C84B31',
    marginBottom: 8,
  },
  restrictedSubtitle: {
    fontSize: 14,
    color: '#56655A',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  backBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#344E41',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    gap: 8,
  },
  backBtnText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 14,
  },
});
