import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  StatusBar,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useFavorites } from '../context/FavoritesContext';
import { COLORS, SHADOWS } from '../utils/theme';
import { PRODUCTS } from '../data/products';

export default function HomeScreen({ navigation }) {
  const { isAuthenticated, userRole, currentUser, logout } = useAuth();
  const { cartCount } = useCart();
  const { favoritesCount } = useFavorites();
  const [selectedRole, setSelectedRole] = useState('Customer');

  const handleLogoutWithConfirm = () => {
    Alert.alert(
      'Log Out',
      'Are you sure you want to log out of your session?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Log Out',
          style: 'destructive',
          onPress: () => logout(),
        },
      ]
    );
  };

  // If user is authenticated, render the rich role-specific dashboard
  if (isAuthenticated) {
    const isCustomer = userRole === 'Customer';
    const userName = currentUser?.name || (isCustomer ? 'Customer' : 'Dhanya (Admin)');

    return (
      <SafeAreaView style={styles.safeArea}>
        <StatusBar barStyle="dark-content" backgroundColor="#F8F5EC" />
        <ScrollView contentContainerStyle={styles.authContainer} showsVerticalScrollIndicator={false}>
          {/* Welcome Header */}
          <View style={styles.authHeader}>
            <View>
              <Text style={styles.greetingText}>Welcome back,</Text>
              <Text style={styles.authUserName} numberOfLines={1}>
                {userName}
              </Text>
            </View>
            <View style={[styles.roleBadge, isCustomer ? styles.customerBadge : styles.adminBadge]}>
              <Ionicons
                name={isCustomer ? 'person' : 'shield-checkmark'}
                size={14}
                color={isCustomer ? COLORS.primary : COLORS.adminBlue}
              />
              <Text style={[styles.roleBadgeText, isCustomer ? styles.customerBadgeText : styles.adminBadgeText]}>
                {userRole || 'User'}
              </Text>
            </View>
          </View>

          {/* Hero Banner */}
          <View style={[styles.heroCard, isCustomer ? styles.customerHero : styles.adminHero]}>
            <View style={styles.heroContent}>
              <Text style={styles.heroTitle}>
                {isCustomer ? 'Fresh Groceries at Your Doorstep' : 'Store Management Console'}
              </Text>
              <Text style={styles.heroSubtitle}>
                {isCustomer
                  ? 'Handpicked organic fruits, farm-fresh vegetables, and daily dairy.'
                  : 'Manage store catalog, oversee stock, and monitor customer orders.'}
              </Text>
              {isCustomer ? (
                <TouchableOpacity
                  style={styles.heroCtaBtn}
                  onPress={() => navigation.navigate('Products')}
                  activeOpacity={0.85}
                >
                  <Text style={styles.heroCtaText}>Shop Now</Text>
                  <Ionicons name="arrow-forward" size={14} color={COLORS.primaryDark} />
                </TouchableOpacity>
              ) : null}
            </View>
            <View style={styles.heroIconCircle}>
              <Ionicons
                name={isCustomer ? 'cart' : 'storefront'}
                size={34}
                color="#FFFFFF"
              />
            </View>
          </View>

          {/* Promotional Offer Banner for Customers */}
          {isCustomer && (
            <View style={styles.promoBanner}>
              <View style={styles.promoIconBox}>
                <Ionicons name="sparkles" size={20} color="#FFA000" />
              </View>
              <View style={styles.promoTextCol}>
                <Text style={styles.promoTitle}>Super Saver Deal: Up to 30% Off</Text>
                <Text style={styles.promoDesc}>Fresh Kashmiri apples & organic paneer on sale today</Text>
              </View>
            </View>
          )}

          {/* Navigation Action Tiles */}
          <Text style={styles.sectionHeading}>Quick Navigation</Text>

          <View style={styles.tileGrid}>
            <TouchableOpacity
              style={[styles.actionTile, !isCustomer && styles.actionTileFull]}
              onPress={() => navigation.navigate('Products')}
              activeOpacity={0.8}
            >
              <View style={[styles.tileIconBg, { backgroundColor: '#EBF0E6' }]}>
                <Ionicons name="grid" size={22} color="#344E41" />
              </View>
              <Text style={styles.tileTitle}>Products</Text>
              <Text style={styles.tileDesc}>
                {isCustomer
                  ? `${PRODUCTS.length} Fresh Items`
                  : `Manage ${PRODUCTS.length} Catalog Items`}
              </Text>
            </TouchableOpacity>

            {isCustomer && (
              <>
                <TouchableOpacity
                  style={styles.actionTile}
                  onPress={() => navigation.navigate('Cart')}
                  activeOpacity={0.8}
                >
                  <View style={[styles.tileIconBg, { backgroundColor: '#FBECE8' }]}>
                    <Ionicons name="cart" size={22} color="#D97757" />
                    {cartCount > 0 ? (
                      <View style={styles.tileBadge}>
                        <Text style={styles.tileBadgeText}>{cartCount}</Text>
                      </View>
                    ) : null}
                  </View>
                  <Text style={styles.tileTitle}>My Cart</Text>
                  <Text style={styles.tileDesc}>
                    {cartCount > 0 ? `${cartCount} items inside` : 'Basket is empty'}
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.actionTile}
                  onPress={() => navigation.navigate('Favorites')}
                  activeOpacity={0.8}
                >
                  <View style={[styles.tileIconBg, { backgroundColor: '#FBECE8' }]}>
                    <Ionicons name="heart" size={22} color="#D97757" />
                    {favoritesCount > 0 ? (
                      <View style={[styles.tileBadge, { backgroundColor: '#D97757' }]}>
                        <Text style={styles.tileBadgeText}>{favoritesCount}</Text>
                      </View>
                    ) : null}
                  </View>
                  <Text style={styles.tileTitle}>Favorites</Text>
                  <Text style={styles.tileDesc}>
                    {favoritesCount > 0 ? `${favoritesCount} saved items` : 'Save top picks'}
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.actionTile}
                  onPress={() => navigation.navigate('Profile')}
                  activeOpacity={0.8}
                >
                  <View style={[styles.tileIconBg, { backgroundColor: '#EBF0E6' }]}>
                    <Ionicons name="person" size={22} color="#344E41" />
                  </View>
                  <Text style={styles.tileTitle}>My Profile</Text>
                  <Text style={styles.tileDesc}>Account & Address</Text>
                </TouchableOpacity>
              </>
            )}
          </View>

          {/* Drawer & Logout Controls */}
          <View style={styles.bottomCard}>
            <TouchableOpacity
              style={styles.drawerButton}
              onPress={() => navigation.openDrawer && navigation.openDrawer()}
              activeOpacity={0.8}
            >
              <Ionicons name="menu-outline" size={20} color="#FFFFFF" />
              <Text style={styles.drawerButtonText}>Open Side Menu</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.logoutButton}
              onPress={handleLogoutWithConfirm}
              activeOpacity={0.8}
            >
              <Ionicons name="log-out-outline" size={20} color="#D32F2F" />
              <Text style={styles.logoutButtonText}>Log Out</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  // Unauthenticated Welcome / Landing Screen (Figma Inspired)
  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" backgroundColor="#F8F5EC" />
      <ScrollView contentContainerStyle={styles.landingContainer} showsVerticalScrollIndicator={false}>
        {/* Brand Header */}
        <View style={styles.brandContainer}>
          <View style={styles.logoCircle}>
            <Ionicons name="basket" size={44} color="#FFFFFF" />
          </View>
          <Text style={styles.brandTitle}>FreshGrocer</Text>
          <View style={styles.badgePill}>
            <Ionicons name="leaf" size={13} color="#A3B18A" />
            <Text style={styles.badgePillText}>100% Organic & Farm-Fresh</Text>
          </View>
          <Text style={styles.tagline}>
            Your daily fresh groceries, dairy, and fruits delivered fast in Indian Rupees (₹).
          </Text>
        </View>

        {/* Role Selection Section */}
        <View style={styles.roleSelectionBox}>
          <Text style={styles.roleBoxHeading}>Select Login Role</Text>
          <Text style={styles.roleBoxSubtitle}>
            Choose your account portal to proceed
          </Text>

          <View style={styles.roleOptionsRow}>
            {/* Customer Role Pill */}
            <TouchableOpacity
              style={[
                styles.rolePill,
                selectedRole === 'Customer' && styles.rolePillActiveCustomer,
              ]}
              onPress={() => setSelectedRole('Customer')}
              activeOpacity={0.85}
            >
              <View
                style={[
                  styles.roleIconWrap,
                  selectedRole === 'Customer' && styles.roleIconWrapActiveCustomer,
                ]}
              >
                <Ionicons
                  name="person"
                  size={20}
                  color={selectedRole === 'Customer' ? '#FFFFFF' : COLORS.primary}
                />
              </View>
              <Text
                style={[
                  styles.rolePillTitle,
                  selectedRole === 'Customer' && styles.rolePillTitleActive,
                ]}
              >
                Customer
              </Text>
              <Text
                style={[
                  styles.rolePillSub,
                  selectedRole === 'Customer' && styles.rolePillSubActive,
                ]}
              >
                Student / Shopper
              </Text>
            </TouchableOpacity>

            {/* Admin Role Pill */}
            <TouchableOpacity
              style={[
                styles.rolePill,
                selectedRole === 'Admin' && styles.rolePillActiveAdmin,
              ]}
              onPress={() => setSelectedRole('Admin')}
              activeOpacity={0.85}
            >
              <View
                style={[
                  styles.roleIconWrap,
                  selectedRole === 'Admin' && styles.roleIconWrapActiveAdmin,
                ]}
              >
                <Ionicons
                  name="shield-checkmark"
                  size={20}
                  color={selectedRole === 'Admin' ? '#FFFFFF' : COLORS.adminBlue}
                />
              </View>
              <Text
                style={[
                  styles.rolePillTitle,
                  selectedRole === 'Admin' && styles.rolePillTitleActive,
                ]}
              >
                Admin
              </Text>
              <Text
                style={[
                  styles.rolePillSub,
                  selectedRole === 'Admin' && styles.rolePillSubActive,
                ]}
              >
                Store Manager
              </Text>
            </TouchableOpacity>
          </View>

          {/* Role Description Note */}
          <View style={styles.roleNoteBox}>
            <Ionicons
              name="information-circle-outline"
              size={18}
              color={selectedRole === 'Customer' ? COLORS.primary : COLORS.adminBlue}
            />
            <Text style={styles.roleNoteText}>
              {selectedRole === 'Customer'
                ? 'Customers can browse products, manage cart, track favorites, and update profile.'
                : 'Store Admins can access catalog and view customer orders. Demo credentials pre-loaded.'}
            </Text>
          </View>
        </View>

        {/* Action Buttons */}
        <View style={styles.actionButtonsBox}>
          {/* Sign In Button */}
          <TouchableOpacity
            style={styles.signInMainBtn}
            onPress={() => navigation.navigate('SignIn', { initialRole: selectedRole })}
            activeOpacity={0.85}
          >
            <Text style={styles.signInMainBtnText}>
              Sign In as {selectedRole}
            </Text>
            <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
          </TouchableOpacity>

          {/* Sign Up Button (Customer only) */}
          {selectedRole === 'Customer' ? (
            <TouchableOpacity
              style={styles.signUpMainBtn}
              onPress={() => navigation.navigate('SignUp', { initialRole: 'Customer' })}
              activeOpacity={0.85}
            >
              <Text style={styles.signUpMainBtnText}>Create Customer Account</Text>
            </TouchableOpacity>
          ) : (
            <View style={styles.adminDemoHint}>
              <Text style={styles.adminDemoHintText}>
                Default Admin: dhanyakannan276@gmail.com
              </Text>
            </View>
          )}
        </View>

        {/* Grocery Quality Guarantees */}
        <View style={styles.guaranteeRow}>
          <View style={styles.guaranteeItem}>
            <Ionicons name="flash-outline" size={16} color={COLORS.primary} />
            <Text style={styles.guaranteeText}>15-Min Delivery</Text>
          </View>
          <View style={styles.guaranteeDot} />
          <View style={styles.guaranteeItem}>
            <Ionicons name="shield-checkmark-outline" size={16} color={COLORS.primary} />
            <Text style={styles.guaranteeText}>Quality Guaranteed</Text>
          </View>
          <View style={styles.guaranteeDot} />
          <View style={styles.guaranteeItem}>
            <Ionicons name="wallet-outline" size={16} color={COLORS.primary} />
            <Text style={styles.guaranteeText}>Best Prices</Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#F8F5EC',
  },
  landingContainer: {
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '100%',
  },
  brandContainer: {
    alignItems: 'center',
    marginBottom: 24,
  },
  logoCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#344E41',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
    shadowColor: '#344E41',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.25,
    shadowRadius: 10,
    elevation: 6,
  },
  brandTitle: {
    fontSize: 32,
    fontWeight: '800',
    color: '#344E41',
    letterSpacing: -0.5,
  },
  badgePill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EBF0E6',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 20,
    marginTop: 8,
    marginBottom: 8,
  },
  badgePillText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#344E41',
    marginLeft: 6,
  },
  tagline: {
    fontSize: 14,
    color: '#56655A',
    textAlign: 'center',
    maxWidth: 300,
    lineHeight: 20,
  },
  roleSelectionBox: {
    width: '100%',
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 18,
    borderWidth: 1,
    borderColor: '#EDE8DB',
    marginBottom: 20,
    ...SHADOWS.md,
  },
  roleBoxHeading: {
    fontSize: 16,
    fontWeight: '700',
    color: '#344E41',
    marginBottom: 4,
  },
  roleBoxSubtitle: {
    fontSize: 13,
    color: '#56655A',
    marginBottom: 14,
  },
  roleOptionsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  rolePill: {
    flex: 1,
    backgroundColor: '#FAF7F0',
    borderRadius: 14,
    padding: 12,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  rolePillActiveCustomer: {
    backgroundColor: '#EBF0E6',
    borderColor: '#A3B18A',
  },
  rolePillActiveAdmin: {
    backgroundColor: '#EBF2F5',
    borderColor: '#2A5D74',
  },
  roleIconWrap: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 6,
  },
  roleIconWrapActiveCustomer: {
    backgroundColor: '#A3B18A',
  },
  roleIconWrapActiveAdmin: {
    backgroundColor: '#2A5D74',
  },
  rolePillTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#26352B',
  },
  rolePillTitleActive: {
    color: '#344E41',
  },
  rolePillSub: {
    fontSize: 11,
    color: '#56655A',
    marginTop: 2,
  },
  rolePillSubActive: {
    color: '#26352B',
    fontWeight: '600',
  },
  roleNoteBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FAF7F0',
    borderRadius: 10,
    padding: 10,
    marginTop: 12,
    gap: 8,
  },
  roleNoteText: {
    flex: 1,
    fontSize: 12,
    color: '#56655A',
    lineHeight: 16,
  },
  actionButtonsBox: {
    width: '100%',
    gap: 10,
    marginBottom: 20,
  },
  signInMainBtn: {
    flexDirection: 'row',
    backgroundColor: '#D97757',
    paddingVertical: 15,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#D97757',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
    gap: 8,
  },
  signInMainBtnText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
  signUpMainBtn: {
    backgroundColor: '#FFFFFF',
    paddingVertical: 14,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: '#D97757',
  },
  signUpMainBtnText: {
    color: '#D97757',
    fontSize: 15,
    fontWeight: '700',
  },
  adminDemoHint: {
    padding: 8,
    alignItems: 'center',
  },
  adminDemoHintText: {
    fontSize: 12,
    color: '#86968B',
    fontStyle: 'italic',
  },
  guaranteeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  guaranteeItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  guaranteeText: {
    fontSize: 11,
    color: '#56655A',
    fontWeight: '500',
  },
  guaranteeDot: {
    width: 3,
    height: 3,
    borderRadius: 1.5,
    backgroundColor: '#CCD6BD',
  },

  // Authenticated State Styles
  authContainer: {
    padding: 20,
    backgroundColor: '#F8F5EC',
    paddingBottom: 32,
  },
  authHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  greetingText: {
    fontSize: 13,
    color: '#56655A',
  },
  authUserName: {
    fontSize: 22,
    fontWeight: '800',
    color: '#344E41',
    maxWidth: 220,
  },
  roleBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 14,
    gap: 5,
  },
  customerBadge: {
    backgroundColor: '#EBF0E6',
  },
  adminBadge: {
    backgroundColor: '#EBF2F5',
  },
  roleBadgeText: {
    fontSize: 12,
    fontWeight: '700',
  },
  customerBadgeText: {
    color: '#344E41',
  },
  adminBadgeText: {
    color: '#2A5D74',
  },
  heroCard: {
    borderRadius: 18,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 3,
  },
  customerHero: {
    backgroundColor: '#344E41',
    shadowColor: '#344E41',
  },
  adminHero: {
    backgroundColor: '#2A5D74',
    shadowColor: '#2A5D74',
  },
  heroContent: {
    flex: 1,
    marginRight: 10,
  },
  heroTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  heroSubtitle: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.9)',
    lineHeight: 16,
    marginBottom: 10,
  },
  heroCtaBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    backgroundColor: '#D97757',
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 14,
    gap: 4,
  },
  heroCtaText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  heroIconCircle: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(255, 255, 255, 0.18)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  promoBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FDF6E7',
    borderWidth: 1,
    borderColor: '#F3DBAC',
    borderRadius: 14,
    padding: 12,
    marginBottom: 16,
    gap: 10,
  },
  promoIconBox: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  promoTextCol: {
    flex: 1,
  },
  promoTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: '#7A541A',
  },
  promoDesc: {
    fontSize: 11,
    color: '#56655A',
    marginTop: 1,
  },
  sectionHeading: {
    fontSize: 16,
    fontWeight: '700',
    color: '#344E41',
    marginBottom: 12,
  },
  tileGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 20,
  },
  actionTile: {
    width: '48%',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 14,
    borderWidth: 1,
    borderColor: '#EDE8DB',
    ...SHADOWS.sm,
  },
  actionTileFull: {
    width: '100%',
  },
  tileIconBg: {
    width: 42,
    height: 42,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
    position: 'relative',
  },
  tileBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    backgroundColor: '#D97757',
    borderRadius: 9,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  tileBadgeText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  tileTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#344E41',
  },
  tileDesc: {
    fontSize: 11,
    color: '#56655A',
    marginTop: 2,
  },
  bottomCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 14,
    borderWidth: 1,
    borderColor: '#EDE8DB',
    gap: 10,
  },
  drawerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#344E41',
    paddingVertical: 13,
    borderRadius: 12,
    gap: 8,
  },
  drawerButtonText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 14,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FDF1EE',
    borderWidth: 1,
    borderColor: '#F8CDC3',
    paddingVertical: 12,
    borderRadius: 12,
    gap: 8,
  },
  logoutButtonText: {
    color: '#C84B31',
    fontWeight: '700',
    fontSize: 14,
  },
});
