import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  StatusBar,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { PRODUCTS } from '../data/products';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useFavorites } from '../context/FavoritesContext';
import CartBadgeIcon from '../components/CartBadgeIcon';

export default function ProductDetailsScreen({ route, navigation }) {
  const { userRole } = useAuth();
  const { addToCart, getItemQuantity } = useCart();
  const { isFavorite, toggleFavorite } = useFavorites();

  const isCustomer = userRole === 'Customer';

  // Gracefully resolve product from navigation params or catalog lookup
  const product = useMemo(() => {
    if (route.params?.product) {
      return route.params.product;
    }
    const id = route.params?.productId;
    if (id) {
      const found = PRODUCTS.find((p) => p.id === id);
      if (found) return found;
    }
    return null;
  }, [route.params]);

  const [quantity, setQuantity] = useState(1);
  const [imageError, setImageError] = useState(false);
  const [imageLoading, setImageLoading] = useState(true);
  const [feedbackMessage, setFeedbackMessage] = useState('');

  // Handle Admin unauthorized access guard
  if (!isCustomer) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.restrictedContainer}>
          <View style={styles.restrictedIconBox}>
            <Ionicons name="lock-closed" size={48} color="#C62828" />
          </View>
          <Text style={styles.restrictedTitle}>Customer-Only Screen</Text>
          <Text style={styles.restrictedSubtitle}>
            Product Details is restricted to Customer shoppers. Store Administrators manage products from the catalog.
          </Text>
          <TouchableOpacity
            style={styles.backHomeBtn}
            onPress={() => navigation.goBack()}
            activeOpacity={0.8}
          >
            <Ionicons name="arrow-back" size={18} color="#FFFFFF" />
            <Text style={styles.backHomeBtnText}>Go Back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // Handle Missing or Invalid Product gracefully
  if (!product) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.navBar}>
          <TouchableOpacity
            style={styles.navBtn}
            onPress={() => navigation.goBack()}
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
          >
            <Ionicons name="arrow-back" size={24} color="#FFFFFF" />
          </TouchableOpacity>
          <Text style={styles.navTitle}>Product Details</Text>
          <View style={{ width: 40 }} />
        </View>

        <View style={styles.notFoundContainer}>
          <View style={styles.notFoundIconBox}>
            <Ionicons name="alert-circle-outline" size={56} color="#E65100" />
          </View>
          <Text style={styles.notFoundTitle}>Product Not Found</Text>
          <Text style={styles.notFoundSubtitle}>
            We couldn't locate this grocery product. It may have been discontinued or updated.
          </Text>
          <TouchableOpacity
            style={styles.browseCatalogBtn}
            onPress={() => navigation.navigate('Products')}
            activeOpacity={0.85}
          >
            <Ionicons name="grid-outline" size={18} color="#FFFFFF" />
            <Text style={styles.browseCatalogBtnText}>Browse All Products</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const isFav = isFavorite(product.id);
  const inCartQty = getItemQuantity(product.id);

  // Quantity handlers - quantity must never go below 1
  const handleDecreaseQuantity = () => {
    setQuantity((prev) => Math.max(1, prev - 1));
  };

  const handleIncreaseQuantity = () => {
    setQuantity((prev) => prev + 1);
  };

  const handleAddToCart = () => {
    addToCart(product, quantity);
    setFeedbackMessage(`Added ${quantity} ${quantity === 1 ? 'item' : 'items'} to Cart!`);
    setTimeout(() => {
      setFeedbackMessage('');
    }, 2400);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor="#344E41" />

      {/* Top Custom Navigation Bar */}
      <View style={styles.navBar}>
        <TouchableOpacity
          style={styles.navBtn}
          onPress={() => navigation.goBack()}
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
        >
          <Ionicons name="arrow-back" size={24} color="#FFFFFF" />
        </TouchableOpacity>

        <Text style={styles.navTitle} numberOfLines={1}>
          {product.name}
        </Text>

        <View style={styles.navRight}>
          <TouchableOpacity
            style={styles.favoriteHeaderBtn}
            onPress={() => toggleFavorite(product)}
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            activeOpacity={0.7}
          >
            <Ionicons
              name={isFav ? 'heart' : 'heart-outline'}
              size={24}
              color={isFav ? '#D97757' : '#FFFFFF'}
            />
          </TouchableOpacity>

          <CartBadgeIcon
            onPress={() => navigation.navigate('Cart')}
            tintColor="#FFFFFF"
          />
        </View>
      </View>

      {/* Confirmation Feedback Toast */}
      {feedbackMessage ? (
        <View style={styles.feedbackToast}>
          <Ionicons name="checkmark-circle" size={18} color="#FFFFFF" />
          <Text style={styles.feedbackToastText}>{feedbackMessage}</Text>
        </View>
      ) : null}

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Large Product Image Showcase */}
        <View style={styles.imageShowcase}>
          {imageError ? (
            <View style={styles.fallbackContainer}>
              <Ionicons name="basket-outline" size={80} color="#81C784" />
              <Text style={styles.fallbackText}>Image not available</Text>
            </View>
          ) : (
            <>
              <Image
                source={{ uri: product.image }}
                style={styles.largeImage}
                resizeMode="cover"
                onLoadEnd={() => setImageLoading(false)}
                onError={() => {
                  setImageLoading(false);
                  setImageError(true);
                }}
              />
              {imageLoading && (
                <View style={styles.imageLoader}>
                  <ActivityIndicator size="large" color="#344E41" />
                </View>
              )}
            </>
          )}

          {/* Floating Category Pill */}
          <View style={styles.floatingCategoryPill}>
            <Text style={styles.floatingCategoryText}>{product.category}</Text>
          </View>
        </View>

        {/* Product Details Card */}
        <View style={styles.detailsCard}>
          {/* Title & Unit */}
          <Text style={styles.productName}>{product.name}</Text>
          <Text style={styles.productUnit}>{product.unit || '1 unit'}</Text>

          {/* Ratings & Reviews Row */}
          <View style={styles.ratingRow}>
            <View style={styles.starBadge}>
              <Ionicons name="star" size={14} color="#FFA000" />
              <Text style={styles.starBadgeText}>{product.rating || 4.8}</Text>
            </View>
            <Text style={styles.reviewCountText}>
              ({Math.floor((product.rating || 4.8) * 28)} customer reviews)
            </Text>
            <View style={styles.verifiedBadge}>
              <Ionicons name="shield-checkmark" size={13} color="#A3B18A" />
              <Text style={styles.verifiedBadgeText}>100% Quality Assured</Text>
            </View>
          </View>

          {/* Price & In-Cart Status */}
          <View style={styles.priceRow}>
            <View>
              <Text style={styles.priceLabel}>Price</Text>
              <Text style={styles.priceAmount}>
                ₹{product.price}
                <Text style={styles.priceUnitSuffix}> / {product.unit || 'unit'}</Text>
              </Text>
            </View>

            {inCartQty > 0 ? (
              <View style={styles.inCartStatusBadge}>
                <Ionicons name="checkmark-done-circle" size={18} color="#344E41" />
                <Text style={styles.inCartStatusText}>{inCartQty} in Cart</Text>
              </View>
            ) : null}
          </View>

          {/* Value Props & Grocery Highlights */}
          <View style={styles.highlightsContainer}>
            <View style={styles.highlightPill}>
              <Ionicons name="leaf-outline" size={16} color="#A3B18A" />
              <Text style={styles.highlightText}>Organic & Fresh</Text>
            </View>
            <View style={styles.highlightPill}>
              <Ionicons name="flash-outline" size={16} color="#A3B18A" />
              <Text style={styles.highlightText}>Fast Delivery</Text>
            </View>
            <View style={styles.highlightPill}>
              <Ionicons name="sync-outline" size={16} color="#A3B18A" />
              <Text style={styles.highlightText}>Easy Return</Text>
            </View>
          </View>

          {/* Detailed Product Description */}
          <View style={styles.descriptionSection}>
            <Text style={styles.sectionTitle}>Product Details</Text>
            <Text style={styles.descriptionText}>
              {product.description ||
                'Grown with care on certified organic farms, hand-graded for top quality, and cold-chain transported to preserve freshness and nutrition.'}
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* Sticky Bottom Action Bar with Quantity Selector & Add to Cart */}
      <View style={styles.bottomBar}>
        {/* Quantity Selector: minus, count, plus (never below 1) */}
        <View style={styles.quantityController}>
          <TouchableOpacity
            style={[
              styles.quantityButton,
              quantity <= 1 && styles.quantityButtonDisabled,
            ]}
            onPress={handleDecreaseQuantity}
            disabled={quantity <= 1}
            activeOpacity={0.7}
          >
            <Ionicons
              name="remove"
              size={18}
              color={quantity <= 1 ? '#CCD6BD' : '#344E41'}
            />
          </TouchableOpacity>

          <Text style={styles.quantityNumber}>{quantity}</Text>

          <TouchableOpacity
            style={styles.quantityButton}
            onPress={handleIncreaseQuantity}
            activeOpacity={0.7}
          >
            <Ionicons name="add" size={18} color="#344E41" />
          </TouchableOpacity>
        </View>

        {/* Add To Cart Primary Button */}
        <TouchableOpacity
          style={styles.addToCartBtn}
          onPress={handleAddToCart}
          activeOpacity={0.85}
        >
          <Ionicons name="cart" size={20} color="#FFFFFF" />
          <Text style={styles.addToCartBtnText}>
            Add to Cart • ₹{product.price * quantity}
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#344E41',
  },
  navBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: Platform.OS === 'android' ? 12 : 8,
    borderBottomWidth: 1,
    borderBottomColor: '#2C4237',
    backgroundColor: '#344E41',
  },
  navBtn: {
    padding: 6,
  },
  navTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
    flex: 1,
    textAlign: 'center',
    marginHorizontal: 8,
  },
  navRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  favoriteHeaderBtn: {
    padding: 6,
  },
  feedbackToast: {
    position: 'absolute',
    top: 60,
    left: 20,
    right: 20,
    backgroundColor: '#344E41',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    zIndex: 999,
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
    elevation: 6,
  },
  feedbackToastText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 110,
    backgroundColor: '#F8F5EC',
  },
  imageShowcase: {
    width: '100%',
    height: 300,
    backgroundColor: '#FAF7F0',
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
  },
  largeImage: {
    width: '100%',
    height: '100%',
  },
  imageLoader: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(250, 247, 240, 0.7)',
  },
  fallbackContainer: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#EBF0E6',
  },
  fallbackText: {
    fontSize: 13,
    color: '#344E41',
    marginTop: 8,
    fontWeight: '500',
  },
  floatingCategoryPill: {
    position: 'absolute',
    bottom: 16,
    left: 18,
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    paddingHorizontal: 14,
    paddingVertical: 5,
    borderRadius: 20,
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  floatingCategoryText: {
    fontSize: 11,
    fontWeight: '800',
    color: '#A3B18A',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  detailsCard: {
    padding: 22,
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    marginTop: -20,
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: -3 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 4,
  },
  productName: {
    fontSize: 24,
    fontWeight: '800',
    color: '#344E41',
    lineHeight: 30,
    marginBottom: 4,
  },
  productUnit: {
    fontSize: 14,
    color: '#56655A',
    fontWeight: '500',
    marginBottom: 14,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 18,
    gap: 8,
    flexWrap: 'wrap',
  },
  starBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FDF6E7',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    gap: 4,
  },
  starBadgeText: {
    fontSize: 13,
    fontWeight: '800',
    color: '#D49B35',
  },
  reviewCountText: {
    fontSize: 12,
    color: '#56655A',
  },
  verifiedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EBF0E6',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    gap: 4,
    marginLeft: 'auto',
  },
  verifiedBadgeText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#344E41',
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 14,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: '#EDE8DB',
    marginBottom: 18,
  },
  priceLabel: {
    fontSize: 11,
    color: '#56655A',
    textTransform: 'uppercase',
    fontWeight: '600',
  },
  priceAmount: {
    fontSize: 26,
    fontWeight: '800',
    color: '#344E41',
  },
  priceUnitSuffix: {
    fontSize: 13,
    fontWeight: '500',
    color: '#56655A',
  },
  inCartStatusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EBF0E6',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 14,
    gap: 6,
  },
  inCartStatusText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#344E41',
  },
  highlightsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
    gap: 8,
  },
  highlightPill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FAF7F0',
    paddingVertical: 10,
    paddingHorizontal: 6,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#EDE8DB',
    gap: 4,
  },
  highlightText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#26352B',
  },
  descriptionSection: {
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#344E41',
    marginBottom: 8,
  },
  descriptionText: {
    fontSize: 14,
    color: '#26352B',
    lineHeight: 22,
  },
  bottomBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#EDE8DB',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: -3 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 8,
  },
  quantityController: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FAF7F0',
    borderRadius: 14,
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: '#EDE8DB',
  },
  quantityButton: {
    width: 36,
    height: 36,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  quantityButtonDisabled: {
    backgroundColor: '#F5F5F5',
  },
  quantityNumber: {
    fontSize: 17,
    fontWeight: '800',
    color: '#26352B',
    paddingHorizontal: 14,
  },
  addToCartBtn: {
    flex: 1,
    backgroundColor: '#D97757',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 15,
    borderRadius: 14,
    gap: 8,
    shadowColor: '#D97757',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  addToCartBtnText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
  },
  restrictedContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  restrictedIconBox: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#FFEBEE',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  restrictedTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: '#C62828',
    marginBottom: 8,
  },
  restrictedSubtitle: {
    fontSize: 14,
    color: '#616161',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  backHomeBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#D97757',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    gap: 8,
  },
  backHomeBtnText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 14,
  },
  notFoundContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  notFoundIconBox: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: '#FFF3E0',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  notFoundTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: '#E65100',
    marginBottom: 8,
  },
  notFoundSubtitle: {
    fontSize: 14,
    color: '#757575',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  browseCatalogBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#D97757',
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 14,
    gap: 8,
  },
  browseCatalogBtnText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 15,
  },
});
