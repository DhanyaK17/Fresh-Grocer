import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  SafeAreaView,
  StatusBar,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { PRODUCTS, CATEGORIES } from '../data/products';
import ProductCard from '../components/ProductCard';
import CategoryFilter from '../components/CategoryFilter';
import CartBadgeIcon from '../components/CartBadgeIcon';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useFavorites } from '../context/FavoritesContext';
import { COLORS, SHADOWS } from '../utils/theme';

export default function ProductsScreen({ navigation }) {
  const { userRole } = useAuth();
  const { addToCart, getItemQuantity } = useCart();
  const { isFavorite, toggleFavorite } = useFavorites();

  const isCustomer = userRole === 'Customer';

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [toastMessage, setToastMessage] = useState('');

  // Combined Search and Category Filter
  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((product) => {
      // Category filter
      const matchesCategory =
        selectedCategory.toLowerCase() === 'all' ||
        product.category.toLowerCase() === selectedCategory.toLowerCase();

      // Search keyword filter
      const trimmedSearch = searchQuery.trim().toLowerCase();
      const matchesSearch =
        !trimmedSearch ||
        product.name.toLowerCase().includes(trimmedSearch) ||
        product.category.toLowerCase().includes(trimmedSearch);

      return matchesCategory && matchesSearch;
    });
  }, [searchQuery, selectedCategory]);

  const showToast = (message) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage('');
    }, 2200);
  };

  const handleAddToCart = (product) => {
    if (!isCustomer) {
      showToast('Cart is available only to Customers');
      return;
    }
    addToCart(product, 1);
    showToast(`Added ${product.name} to Cart`);
  };

  const handleCardPress = (product) => {
    if (isCustomer) {
      // Navigate to Customer-only ProductDetailsScreen
      navigation.navigate('ProductDetails', {
        productId: product.id,
        product,
        title: product.name,
        price: `₹${product.price}`,
      });
    } else {
      // Admin: Informative feedback that Product Details is a customer feature
      showToast('Product Details view is restricted to Customers');
    }
  };

  const handleClearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" backgroundColor="#F8F5EC" />

      {/* Screen Header Bar */}
      <View style={styles.headerBar}>
        <View style={styles.headerTitles}>
          <Text style={styles.shopTitle}>GroceryShpping</Text>
          <Text style={styles.shopSubtitle}>
            {isCustomer ? 'Fresh groceries delivered in 15 mins' : 'Admin Products Catalog Management'}
          </Text>
        </View>

        {isCustomer && ( 
          <View style={styles.headerActions}>
            <CartBadgeIcon
              onPress={() => navigation.navigate('Cart')}
              tintColor={COLORS.primaryDark}
            />
          </View>
        )}
      </View>

      {/* Toast Notification */}
      {toastMessage ? (
        <View style={styles.toast}>
          <Ionicons name="checkmark-circle" size={18} color="#FFFFFF" />
          <Text style={styles.toastText} numberOfLines={1}>
            {toastMessage}
          </Text>
        </View>
      ) : null}

      {/* Search Input Bar */}
      <View style={styles.searchSection}>
        <View style={styles.searchBar}>
          <Ionicons name="search" size={20} color="#757575" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search fruits, vegetables, dairy, bakery..."
            placeholderTextColor="#9E9E9E"
            value={searchQuery}
            onChangeText={setSearchQuery}
            returnKeyType="search"
            clearButtonMode="while-editing"
          />
          {searchQuery ? (
            <TouchableOpacity
              onPress={() => setSearchQuery('')}
              style={styles.clearSearchBtn}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            >
              <Ionicons name="close-circle" size={18} color="#757575" />
            </TouchableOpacity>
          ) : null}
        </View>
      </View>

      {/* Category Pills Filter */}
      <CategoryFilter
        categories={CATEGORIES}
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
      />

      {/* Products Grid Count Bar */}
      <View style={styles.resultCountBar}>
        <Text style={styles.resultCountText}>
          {filteredProducts.length === 0
            ? 'No products found'
            : `Showing ${filteredProducts.length} ${
                filteredProducts.length === 1 ? 'item' : 'items'
              }${selectedCategory !== 'All' ? ` in ${selectedCategory}` : ''}`}
        </Text>
        {searchQuery || selectedCategory !== 'All' ? (
          <TouchableOpacity onPress={handleClearFilters}>
            <Text style={styles.resetFiltersText}>Reset</Text>
          </TouchableOpacity>
        ) : null}
      </View>

      {/* Products 2-Column Grid */}
      <FlatList
        data={filteredProducts}
        keyExtractor={(item) => item.id}
        numColumns={2}
        contentContainerStyle={styles.listContent}
        columnWrapperStyle={styles.columnWrapper}
        showsVerticalScrollIndicator={false}
        initialNumToRender={8}
        maxToRenderPerBatch={10}
        windowSize={7}
        removeClippedSubviews={Platform.OS === 'android'}
        renderItem={({ item }) => (
          <ProductCard
            product={item}
            onPress={() => handleCardPress(item)}
            onAddToCart={() => handleAddToCart(item)}
            onToggleFavorite={() => toggleFavorite(item)}
            isFavorite={isFavorite(item.id)}
            isCustomer={isCustomer}
            quantityInCart={getItemQuantity(item.id)}
          />
        )}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <View style={styles.emptyIconCircle}>
              <Ionicons name="search-outline" size={44} color="#A3B18A" />
            </View>
            <Text style={styles.emptyTitle}>No matching products</Text>
            <Text style={styles.emptySubtitle}>
              We couldn't find any groceries matching "{searchQuery || selectedCategory}".
              Check your spelling or explore other categories.
            </Text>
            <TouchableOpacity
              style={styles.clearFilterBtn}
              onPress={handleClearFilters}
              activeOpacity={0.8}
            >
              <Ionicons name="refresh" size={16} color="#FFFFFF" />
              <Text style={styles.clearFilterBtnText}>Clear All Filters</Text>
            </TouchableOpacity>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#F8F5EC',
  },
  headerBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: Platform.OS === 'android' ? 12 : 8,
    paddingBottom: 6,
  },
  headerTitles: {
    flex: 1,
  },
  shopTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: '#344E41',
    letterSpacing: -0.5,
  },
  shopSubtitle: {
    fontSize: 12,
    color: '#56655A',
    marginTop: 2,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  toast: {
    position: 'absolute',
    top: 60,
    left: 20,
    right: 20,
    backgroundColor: '#344E41',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    zIndex: 999,
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
    elevation: 6,
  },
  toastText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },
  searchSection: {
    paddingHorizontal: 16,
    marginTop: 4,
    marginBottom: 4,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    paddingHorizontal: 14,
    borderWidth: 1,
    borderColor: '#EDE8DB',
    ...SHADOWS.sm,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 11,
    fontSize: 14,
    color: '#26352B',
  },
  clearSearchBtn: {
    padding: 4,
  },
  resultCountBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 18,
    marginTop: 4,
    marginBottom: 6,
  },
  resultCountText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#56655A',
  },
  resetFiltersText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#D97757',
  },
  listContent: {
    paddingHorizontal: 10,
    paddingBottom: 24,
  },
  columnWrapper: {
    justifyContent: 'space-between',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 48,
    paddingHorizontal: 24,
  },
  emptyIconCircle: {
    width: 76,
    height: 76,
    borderRadius: 38,
    backgroundColor: '#EBF0E6',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 14,
  },
  emptyTitle: {
    fontSize: 17,
    fontWeight: '700',
    color: '#344E41',
    marginBottom: 6,
  },
  emptySubtitle: {
    fontSize: 13,
    color: '#56655A',
    textAlign: 'center',
    lineHeight: 18,
    marginBottom: 18,
  },
  clearFilterBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#D97757',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    gap: 8,
    shadowColor: '#D97757',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 3,
  },
  clearFilterBtnText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 14,
  },
});
