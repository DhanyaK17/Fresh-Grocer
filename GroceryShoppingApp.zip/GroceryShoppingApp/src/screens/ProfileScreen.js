import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { useFavorites } from '../context/FavoritesContext';
import { useCart } from '../context/CartContext';

export default function ProfileScreen({ navigation }) {
  const { currentUser, userRole, logout, deleteCustomerProfile } = useAuth();
  const { favoritesCount } = useFavorites();
  const { cartCount } = useCart();

  // Guard: Profile screen is Customer-only
  if (userRole === 'Admin') {
    return (
      <View style={styles.restrictedContainer}>
        <View style={styles.restrictedIconBox}>
          <Ionicons name="shield-outline" size={54} color="#C62828" />
        </View>
        <Text style={styles.restrictedTitle}>Customer-Only Screen</Text>
        <Text style={styles.restrictedSubtitle}>
          The Profile screen is reserved for Customer accounts. Admin users manage store
          inventory and orders through the Admin Drawer.
        </Text>
        <TouchableOpacity
          style={styles.restrictedBtn}
          onPress={() => navigation.navigate('Products')}
        >
          <Text style={styles.restrictedBtnText}>Go to Products Catalog</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // Generate initials for avatar placeholder
  const getInitials = (name) => {
    if (!name || typeof name !== 'string') return 'C';
    const parts = name.trim().split(' ').filter(Boolean);
    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  };

  const handleLogout = () => {
    Alert.alert(
      'Log Out',
      'Are you sure you want to log out of your account?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Log Out',
          style: 'destructive',
          onPress: () => logout(),
        },
      ]
    );
  };

  const handleDeleteProfile = () => {
    Alert.alert(
      'Delete Profile',
      'Are you sure you want to delete your profile? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete Profile',
          style: 'destructive',
          onPress: async () => {
            const result = await deleteCustomerProfile();
            if (result.success) {
              Alert.alert('Profile Deleted', result.message);
            } else {
              Alert.alert('Error', result.error || 'Failed to delete profile.');
            }
          },
        },
      ]
    );
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <StatusBar barStyle="dark-content" backgroundColor="#F8F9FA" />

      {/* Header Avatar Card */}
      <View style={styles.profileHeaderCard}>
        <View style={styles.avatarRing}>
          <View style={styles.avatarCircle}>
            <Text style={styles.avatarInitials}>
              {getInitials(currentUser?.name)}
            </Text>
          </View>
          <View style={styles.verifiedBadge}>
            <Ionicons name="checkmark" size={14} color="#FFFFFF" />
          </View>
        </View>

        <Text style={styles.userName}>{currentUser?.name || 'Customer'}</Text>
        <Text style={styles.userEmail}>{currentUser?.email || 'customer@groceryshop.com'}</Text>

        <View style={styles.roleBadge}>
          <Ionicons name="person" size={13} color="#A3B18A" style={{ marginRight: 4 }} />
          <Text style={styles.roleBadgeText}>Verified Customer</Text>
        </View>
      </View>

      {/* Account Quick Stats */}
      <View style={styles.statsRow}>
        <TouchableOpacity
          style={styles.statCard}
          onPress={() => navigation.navigate('Favorites')}
        >
          <View style={[styles.statIconBox, { backgroundColor: '#FBECE8' }]}>
            <Ionicons name="heart" size={20} color="#D97757" />
          </View>
          <Text style={styles.statNumber}>{favoritesCount}</Text>
          <Text style={styles.statLabel}>Favorites</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.statCard}
          onPress={() => navigation.navigate('Cart')}
        >
          <View style={[styles.statIconBox, { backgroundColor: '#FBECE8' }]}>
            <Ionicons name="cart" size={20} color="#D97757" />
          </View>
          <Text style={styles.statNumber}>{cartCount}</Text>
          <Text style={styles.statLabel}>Cart Items</Text>
        </TouchableOpacity>

        <View style={styles.statCard}>
          <View style={[styles.statIconBox, { backgroundColor: '#E3F2FD' }]}>
            <Ionicons name="shield-checkmark" size={20} color="#1976D2" />
          </View>
          <Text style={styles.statNumber}>Active</Text>
          <Text style={styles.statLabel}>Status</Text>
        </View>
      </View>

      {/* Profile Details Card */}
      <View style={styles.sectionCard}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Profile Details</Text>
          <TouchableOpacity
            style={styles.editIconBtn}
            onPress={() => navigation.navigate('EditProfile')}
          >
            <Ionicons name="create-outline" size={18} color="#D97757" />
            <Text style={styles.editIconText}>Edit</Text>
          </TouchableOpacity>
        </View>

        {/* Full Name */}
        <View style={styles.infoRow}>
          <View style={styles.infoIconBox}>
            <Ionicons name="person-outline" size={20} color="#344E41" />
          </View>
          <View style={styles.infoContent}>
            <Text style={styles.infoLabel}>Full Name</Text>
            <Text style={styles.infoValue}>
              {currentUser?.name || 'Not provided'}
            </Text>
          </View>
        </View>

        <View style={styles.divider} />

        {/* Email */}
        <View style={styles.infoRow}>
          <View style={styles.infoIconBox}>
            <Ionicons name="mail-outline" size={20} color="#344E41" />
          </View>
          <View style={styles.infoContent}>
            <Text style={styles.infoLabel}>Email Address</Text>
            <Text style={styles.infoValue}>
              {currentUser?.email || 'Not provided'}
            </Text>
          </View>
        </View>

        <View style={styles.divider} />

        {/* Phone */}
        <View style={styles.infoRow}>
          <View style={styles.infoIconBox}>
            <Ionicons name="call-outline" size={20} color="#344E41" />
          </View>
          <View style={styles.infoContent}>
            <Text style={styles.infoLabel}>Phone Number</Text>
            <Text style={styles.infoValue}>
              {currentUser?.phone || 'Not provided'}
            </Text>
          </View>
        </View>

        <View style={styles.divider} />

        {/* Delivery Address */}
        <View style={styles.infoRow}>
          <View style={styles.infoIconBox}>
            <Ionicons name="location-outline" size={20} color="#344E41" />
          </View>
          <View style={styles.infoContent}>
            <Text style={styles.infoLabel}>Delivery Address</Text>
            <Text style={[styles.infoValue, !currentUser?.address && styles.placeholderText]}>
              {currentUser?.address ? currentUser.address : 'Not provided (tap Edit Profile to add)'}
            </Text>
          </View>
        </View>
      </View>

      {/* Action Buttons */}
      <View style={styles.actionSection}>
        <TouchableOpacity
          style={styles.primaryBtn}
          onPress={() => navigation.navigate('EditProfile')}
          activeOpacity={0.8}
        >
          <Ionicons name="create-outline" size={20} color="#FFFFFF" style={{ marginRight: 8 }} />
          <Text style={styles.primaryBtnText}>Edit Profile</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.dangerOutlineBtn}
          onPress={handleDeleteProfile}
          activeOpacity={0.8}
        >
          <Ionicons name="trash-outline" size={18} color="#D32F2F" style={{ marginRight: 8 }} />
          <Text style={styles.dangerOutlineBtnText}>Delete Profile</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.logoutBtn}
          onPress={handleLogout}
          activeOpacity={0.8}
        >
          <Ionicons name="log-out-outline" size={18} color="#546E7A" style={{ marginRight: 8 }} />
          <Text style={styles.logoutBtnText}>Log Out</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F5EC',
  },
  content: {
    padding: 20,
    paddingBottom: 40,
  },
  restrictedContainer: {
    flex: 1,
    padding: 28,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F8F5EC',
  },
  restrictedIconBox: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: '#FDF1EE',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  restrictedTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#C84B31',
    marginBottom: 10,
    textAlign: 'center',
  },
  restrictedSubtitle: {
    fontSize: 14,
    color: '#56655A',
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 24,
  },
  restrictedBtn: {
    backgroundColor: '#344E41',
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 12,
  },
  restrictedBtnText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 15,
  },
  profileHeaderCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    paddingVertical: 24,
    paddingHorizontal: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#EDE8DB',
    marginBottom: 16,
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 10,
    elevation: 3,
  },
  avatarRing: {
    width: 92,
    height: 92,
    borderRadius: 46,
    borderWidth: 3,
    borderColor: '#A3B18A',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
    position: 'relative',
  },
  avatarCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#344E41',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarInitials: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#FFFFFF',
    letterSpacing: 1,
  },
  verifiedBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#A3B18A',
    borderWidth: 2,
    borderColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  userName: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#344E41',
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 14,
    color: '#56655A',
    marginBottom: 10,
  },
  roleBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EBF0E6',
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 16,
  },
  roleBadgeText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#344E41',
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    paddingVertical: 14,
    paddingHorizontal: 8,
    alignItems: 'center',
    marginHorizontal: 4,
    borderWidth: 1,
    borderColor: '#EDE8DB',
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 3,
    elevation: 1,
  },
  statIconBox: {
    width: 38,
    height: 38,
    borderRadius: 19,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 6,
  },
  statNumber: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#344E41',
  },
  statLabel: {
    fontSize: 11,
    color: '#56655A',
    marginTop: 2,
  },
  sectionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: '#EDE8DB',
    marginBottom: 20,
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
    paddingBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#EDE8DB',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#344E41',
  },
  editIconBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  editIconText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#D97757',
    marginLeft: 4,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
  },
  infoIconBox: {
    width: 38,
    height: 38,
    borderRadius: 10,
    backgroundColor: '#EBF0E6',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
  },
  infoContent: {
    flex: 1,
  },
  infoLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: '#56655A',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: 2,
  },
  infoValue: {
    fontSize: 15,
    fontWeight: '600',
    color: '#26352B',
  },
  placeholderText: {
    color: '#86968B',
    fontWeight: 'normal',
    fontStyle: 'italic',
  },
  divider: {
    height: 1,
    backgroundColor: '#EDE8DB',
    marginVertical: 6,
  },
  actionSection: {
    marginTop: 6,
  },
  primaryBtn: {
    flexDirection: 'row',
    backgroundColor: '#D97757',
    paddingVertical: 14,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
    shadowColor: '#D97757',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 3,
  },
  primaryBtnText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
  },
  dangerOutlineBtn: {
    flexDirection: 'row',
    backgroundColor: '#FDF1EE',
    borderWidth: 1,
    borderColor: '#F8CDC3',
    paddingVertical: 13,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  dangerOutlineBtnText: {
    color: '#C84B31',
    fontWeight: 'bold',
    fontSize: 15,
  },
  logoutBtn: {
    flexDirection: 'row',
    backgroundColor: '#FAF7F0',
    borderWidth: 1,
    borderColor: '#EDE8DB',
    paddingVertical: 13,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoutBtnText: {
    color: '#344E41',
    fontWeight: '600',
    fontSize: 15,
  },
});
