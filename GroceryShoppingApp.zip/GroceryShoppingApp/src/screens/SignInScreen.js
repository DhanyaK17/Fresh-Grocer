import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  SafeAreaView,
  StatusBar,
  ActivityIndicator,
  Platform,
  KeyboardAvoidingView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { validateSignInForm } from '../utils/validation';
import { COLORS, SHADOWS } from '../utils/theme';

export default function SignInScreen({ route, navigation }) {
  const { login } = useAuth();

  // Role can be preselected from HomeScreen or toggled here
  const [role, setRole] = useState(route.params?.initialRole || 'Customer');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [fieldErrors, setFieldErrors] = useState({});
  const [generalError, setGeneralError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isCustomer = role === 'Customer';

  const handleSignIn = async () => {
    setGeneralError('');

    // Field validation
    const validation = validateSignInForm({ email, password });
    if (!validation.isValid) {
      setFieldErrors(validation.errors);
      return;
    }
    setFieldErrors({});
    setIsSubmitting(true);

    try {
      const result = await login({ email, password, role });
      if (!result.success) {
        setGeneralError(result.error || 'Login failed. Please check your credentials.');
      }
      // If success, AuthContext updates isAuthenticated, AppNavigator automatically routes
    } catch (err) {
      setGeneralError('An unexpected error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFillAdminDemo = () => {
    setRole('Admin');
    setEmail('dhanyakannan276@gmail.com');
    setPassword('Dhanzz@12');
    setFieldErrors({});
    setGeneralError('');
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" backgroundColor="#F8F5EC" />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.container}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Top Back Navigation Bar */}
          <View style={styles.topNav}>
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => navigation.navigate('Home')}
              activeOpacity={0.7}
            >
              <Ionicons name="arrow-back" size={20} color={COLORS.forestGreen} />
              <Text style={styles.backButtonText}>Home</Text>
            </TouchableOpacity>

            <Text style={styles.topNavTitle}>Sign In</Text>
            <View style={{ width: 60 }} />
          </View>

          {/* Header & Logo */}
          <View style={styles.header}>
            <View style={styles.logoCircle}>
              <Ionicons name="basket" size={32} color="#FFFFFF" />
            </View>
            <Text style={styles.title}>Welcome Back</Text>
            <Text style={styles.subtitle}>
              Sign in to start ordering fresh groceries or manage the store
            </Text>
          </View>

          {/* Role Toggle Switch */}
          <View style={styles.roleToggleContainer}>
            <TouchableOpacity
              style={[
                styles.roleToggleBtn,
                isCustomer && styles.roleToggleBtnActiveCustomer,
              ]}
              onPress={() => {
                setRole('Customer');
                setGeneralError('');
                setFieldErrors({});
              }}
              activeOpacity={0.8}
            >
              <Ionicons
                name="person"
                size={16}
                color={isCustomer ? '#FFFFFF' : '#757575'}
              />
              <Text
                style={[
                  styles.roleToggleText,
                  isCustomer && styles.roleToggleTextActive,
                ]}
              >
                Customer
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.roleToggleBtn,
                !isCustomer && styles.roleToggleBtnActiveAdmin,
              ]}
              onPress={() => {
                setRole('Admin');
                setGeneralError('');
                setFieldErrors({});
              }}
              activeOpacity={0.8}
            >
              <Ionicons
                name="shield-checkmark"
                size={16}
                color={!isCustomer ? '#FFFFFF' : '#757575'}
              />
              <Text
                style={[
                  styles.roleToggleText,
                  !isCustomer && styles.roleToggleTextActive,
                ]}
              >
                Admin
              </Text>
            </TouchableOpacity>
          </View>

          {/* General Error Banner */}
          {generalError ? (
            <View style={styles.errorBanner}>
              <Ionicons name="alert-circle" size={18} color="#D32F2F" />
              <Text style={styles.errorBannerText}>{generalError}</Text>
            </View>
          ) : null}

          {/* Sign In Form */}
          <View style={styles.formCard}>
            {/* Email Input */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Email Address</Text>
              <View
                style={[
                  styles.inputWrapper,
                  fieldErrors.email && styles.inputWrapperError,
                ]}
              >
                <Ionicons
                  name="mail-outline"
                  size={20}
                  color={fieldErrors.email ? '#D32F2F' : COLORS.forestGreen}
                  style={styles.inputIcon}
                />
                <TextInput
                  style={styles.textInput}
                  placeholder={isCustomer ? 'name@example.com' : 'dhanyakannan276@gmail.com'}
                  placeholderTextColor={COLORS.textMuted}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                  value={email}
                  onChangeText={(text) => {
                    setEmail(text);
                    if (fieldErrors.email) {
                      setFieldErrors({ ...fieldErrors, email: null });
                    }
                  }}
                />
              </View>
              {fieldErrors.email ? (
                <Text style={styles.fieldErrorText}>{fieldErrors.email}</Text>
              ) : null}
            </View>

            {/* Password Input */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Password</Text>
              <View
                style={[
                  styles.inputWrapper,
                  fieldErrors.password && styles.inputWrapperError,
                ]}
              >
                <Ionicons
                  name="lock-closed-outline"
                  size={20}
                  color={fieldErrors.password ? '#D32F2F' : COLORS.forestGreen}
                  style={styles.inputIcon}
                />
                <TextInput
                  style={styles.textInput}
                  placeholder="Enter your password"
                  placeholderTextColor={COLORS.textMuted}
                  secureTextEntry={!showPassword}
                  value={password}
                  onChangeText={(text) => {
                    setPassword(text);
                    if (fieldErrors.password) {
                      setFieldErrors({ ...fieldErrors, password: null });
                    }
                  }}
                />
                <TouchableOpacity
                  onPress={() => setShowPassword(!showPassword)}
                  style={styles.eyeBtn}
                  hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                >
                  <Ionicons
                    name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                    size={20}
                    color="#757575"
                  />
                </TouchableOpacity>
              </View>
              {fieldErrors.password ? (
                <Text style={styles.fieldErrorText}>{fieldErrors.password}</Text>
              ) : null}
            </View>

            {/* Submit Button */}
            <TouchableOpacity
              style={[
                styles.submitBtn,
                !isCustomer && styles.submitBtnAdmin,
                isSubmitting && styles.submitBtnDisabled,
              ]}
              onPress={handleSignIn}
              disabled={isSubmitting}
              activeOpacity={0.85}
            >
              {isSubmitting ? (
                <ActivityIndicator color="#FFFFFF" size="small" />
              ) : (
                <>
                  <Text style={styles.submitBtnText}>
                    Sign In as {role}
                  </Text>
                  <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
                </>
              )}
            </TouchableOpacity>

            {/* Quick Demo Fill Shortcut for Admin */}
            {!isCustomer && (
              <TouchableOpacity
                style={styles.demoFillBtn}
                onPress={handleFillAdminDemo}
                activeOpacity={0.7}
              >
                <Ionicons name="flash" size={14} color={COLORS.adminBlue} />
                <Text style={styles.demoFillText}>Auto-fill Default Admin Credentials</Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Switch to Sign Up (Customers) */}
          {isCustomer ? (
            <View style={styles.switchAuthRow}>
              <Text style={styles.switchAuthPrompt}>New to FreshGrocer? </Text>
              <TouchableOpacity
                onPress={() => navigation.navigate('SignUp', { initialRole: 'Customer' })}
              >
                <Text style={styles.switchAuthLink}>Create Account</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <View style={styles.switchAuthRow}>
              <Text style={styles.switchAuthPrompt}>Customer Shopper? </Text>
              <TouchableOpacity onPress={() => setRole('Customer')}>
                <Text style={styles.switchAuthLink}>Switch to Customer</Text>
              </TouchableOpacity>
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#F8F5EC',
  },
  container: {
    paddingHorizontal: 20,
    paddingBottom: 36,
  },
  topNav: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    paddingHorizontal: 8,
    borderRadius: 8,
  },
  backButtonText: {
    color: '#344E41',
    fontSize: 14,
    fontWeight: '700',
    marginLeft: 4,
  },
  topNavTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: '#344E41',
  },
  header: {
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 20,
  },
  logoCircle: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#344E41',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
    ...SHADOWS.sm,
  },
  title: {
    fontSize: 26,
    fontWeight: '800',
    color: '#344E41',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 13,
    color: '#56655A',
    textAlign: 'center',
    maxWidth: 290,
    lineHeight: 18,
  },
  roleToggleContainer: {
    flexDirection: 'row',
    backgroundColor: '#EAE5D8',
    borderRadius: 14,
    padding: 4,
    marginBottom: 16,
  },
  roleToggleBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 10,
    gap: 6,
  },
  roleToggleBtnActiveCustomer: {
    backgroundColor: '#344E41',
  },
  roleToggleBtnActiveAdmin: {
    backgroundColor: COLORS.adminBlue,
  },
  roleToggleText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#56655A',
  },
  roleToggleTextActive: {
    color: '#FFFFFF',
    fontWeight: '700',
  },
  errorBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FDF1EE',
    borderWidth: 1,
    borderColor: '#F8CDC3',
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
    gap: 8,
  },
  errorBannerText: {
    flex: 1,
    fontSize: 13,
    color: '#C84B31',
    lineHeight: 18,
  },
  formCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 20,
    borderWidth: 1,
    borderColor: '#EDE8DB',
    marginBottom: 20,
    ...SHADOWS.md,
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: '#26352B',
    marginBottom: 6,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FAF8F3',
    borderWidth: 1,
    borderColor: '#EDE8DB',
    borderRadius: 12,
    paddingHorizontal: 12,
  },
  inputWrapperError: {
    borderColor: '#C84B31',
    backgroundColor: '#FDF1EE',
  },
  inputIcon: {
    marginRight: 10,
  },
  textInput: {
    flex: 1,
    height: 48,
    fontSize: 14,
    color: '#26352B',
  },
  eyeBtn: {
    padding: 6,
  },
  fieldErrorText: {
    color: '#C84B31',
    fontSize: 11,
    marginTop: 4,
    marginLeft: 4,
  },
  submitBtn: {
    flexDirection: 'row',
    backgroundColor: '#D97757',
    height: 50,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 8,
    gap: 8,
    shadowColor: '#D97757',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
    elevation: 3,
  },
  submitBtnAdmin: {
    backgroundColor: COLORS.adminBlue,
    shadowColor: COLORS.adminBlue,
  },
  submitBtnDisabled: {
    opacity: 0.7,
  },
  submitBtnText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
  },
  demoFillBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#EBF2F5',
    borderRadius: 10,
    paddingVertical: 10,
    marginTop: 12,
    gap: 6,
  },
  demoFillText: {
    color: COLORS.adminBlue,
    fontSize: 12,
    fontWeight: '700',
  },
  switchAuthRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 8,
  },
  switchAuthPrompt: {
    fontSize: 13,
    color: '#56655A',
  },
  switchAuthLink: {
    fontSize: 13,
    fontWeight: '700',
    color: '#D97757',
  },
});
