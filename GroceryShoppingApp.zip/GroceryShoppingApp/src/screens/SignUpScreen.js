import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  SafeAreaView,
  StatusBar,
  ActivityIndicator,
  Platform,
  KeyboardAvoidingView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { validateSignUpForm } from '../utils/validation';
import { COLORS, SHADOWS } from '../utils/theme';

export default function SignUpScreen({ navigation }) {
  const { registerCustomer } = useAuth();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [fieldErrors, setFieldErrors] = useState({});
  const [generalError, setGeneralError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSignUp = async () => {
    setGeneralError('');
    setSuccessMessage('');

    // Validate form
    const validation = validateSignUpForm({
      name,
      email,
      phone,
      password,
      confirmPassword,
    });

    if (!validation.isValid) {
      setFieldErrors(validation.errors);
      return;
    }

    setFieldErrors({});
    setIsSubmitting(true);

    try {
      const result = await registerCustomer({
        name,
        email,
        phone,
        password,
      });

      if (!result.success) {
        setGeneralError(result.error);
      } else {
        setSuccessMessage(result.message || 'Registration successful! You can now sign in.');
        setName('');
        setEmail('');
        setPhone('');
        setPassword('');
        setConfirmPassword('');
      }
    } catch (err) {
      setGeneralError('An unexpected error occurred during registration. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" backgroundColor="#F8F5EC" />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.container}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Top Back Navigation Bar */}
          <View style={styles.topNav}>
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => navigation.navigate('Home')}
              activeOpacity={0.7}
            >
              <Ionicons name="arrow-back" size={20} color="#344E41" />
              <Text style={styles.backButtonText}>Home</Text>
            </TouchableOpacity>

            <Text style={styles.topNavTitle}>Sign Up</Text>
            <View style={{ width: 60 }} />
          </View>

          {/* Header */}
          <View style={styles.header}>
            <View style={styles.logoCircle}>
              <Ionicons name="person-add" size={28} color="#FFFFFF" />
            </View>
            <Text style={styles.title}>Create Customer Account</Text>
            <Text style={styles.subtitle}>
              Register to shop fresh farm groceries delivered to your door
            </Text>

            {/* Role Clarification Pill */}
            <View style={styles.roleNoticeBadge}>
              <Ionicons name="leaf" size={13} color="#A3B18A" />
              <Text style={styles.roleNoticeText}>
                Role: Customer (Student Shopper)
              </Text>
            </View>
          </View>

          {/* Success Banner */}
          {successMessage ? (
            <View style={styles.successBanner}>
              <View style={styles.successHeaderRow}>
                <Ionicons name="checkmark-circle" size={22} color="#344E41" />
                <Text style={styles.successTitle}>Account Created!</Text>
              </View>
              <Text style={styles.successBody}>{successMessage}</Text>
              <TouchableOpacity
                style={styles.successSignInBtn}
                onPress={() => navigation.navigate('SignIn', { initialRole: 'Customer' })}
              >
                <Text style={styles.successSignInBtnText}>Go to Sign In</Text>
                <Ionicons name="arrow-forward" size={16} color="#FFFFFF" />
              </TouchableOpacity>
            </View>
          ) : null}

          {/* General Error Banner */}
          {generalError ? (
            <View style={styles.errorBanner}>
              <Ionicons name="alert-circle" size={18} color="#C84B31" />
              <Text style={styles.errorBannerText}>{generalError}</Text>
            </View>
          ) : null}

          {/* Sign Up Form */}
          <View style={styles.formCard}>
            {/* Full Name */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>
                Full Name <Text style={styles.asterisk}>*</Text>
              </Text>
              <View
                style={[
                  styles.inputWrapper,
                  fieldErrors.name && styles.inputWrapperError,
                ]}
              >
                <Ionicons
                  name="person-outline"
                  size={20}
                  color={fieldErrors.name ? '#C84B31' : '#344E41'}
                  style={styles.inputIcon}
                />
                <TextInput
                  style={styles.textInput}
                  placeholder="e.g. John Doe"
                  placeholderTextColor="#86968B"
                  autoCapitalize="words"
                  value={name}
                  onChangeText={(text) => {
                    setName(text);
                    if (fieldErrors.name) setFieldErrors({ ...fieldErrors, name: null });
                  }}
                />
              </View>
              {fieldErrors.name ? (
                <Text style={styles.fieldErrorText}>{fieldErrors.name}</Text>
              ) : null}
            </View>

            {/* Email Address */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>
                Email Address <Text style={styles.asterisk}>*</Text>
              </Text>
              <View
                style={[
                  styles.inputWrapper,
                  fieldErrors.email && styles.inputWrapperError,
                ]}
              >
                <Ionicons
                  name="mail-outline"
                  size={20}
                  color={fieldErrors.email ? '#C84B31' : '#344E41'}
                  style={styles.inputIcon}
                />
                <TextInput
                  style={styles.textInput}
                  placeholder="name@example.com"
                  placeholderTextColor="#86968B"
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                  value={email}
                  onChangeText={(text) => {
                    setEmail(text);
                    if (fieldErrors.email) setFieldErrors({ ...fieldErrors, email: null });
                  }}
                />
              </View>
              {fieldErrors.email ? (
                <Text style={styles.fieldErrorText}>{fieldErrors.email}</Text>
              ) : null}
            </View>

            {/* Phone Number */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>
                Phone Number <Text style={styles.asterisk}>*</Text>
              </Text>
              <View
                style={[
                  styles.inputWrapper,
                  fieldErrors.phone && styles.inputWrapperError,
                ]}
              >
                <Ionicons
                  name="call-outline"
                  size={20}
                  color={fieldErrors.phone ? '#C84B31' : '#344E41'}
                  style={styles.inputIcon}
                />
                <TextInput
                  style={styles.textInput}
                  placeholder="10-digit mobile number"
                  placeholderTextColor="#86968B"
                  keyboardType="phone-pad"
                  value={phone}
                  onChangeText={(text) => {
                    setPhone(text);
                    if (fieldErrors.phone) setFieldErrors({ ...fieldErrors, phone: null });
                  }}
                />
              </View>
              {fieldErrors.phone ? (
                <Text style={styles.fieldErrorText}>{fieldErrors.phone}</Text>
              ) : null}
            </View>

            {/* Password */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>
                Password <Text style={styles.asterisk}>*</Text>
              </Text>
              <View
                style={[
                  styles.inputWrapper,
                  fieldErrors.password && styles.inputWrapperError,
                ]}
              >
                <Ionicons
                  name="lock-closed-outline"
                  size={20}
                  color={fieldErrors.password ? '#C84B31' : '#344E41'}
                  style={styles.inputIcon}
                />
                <TextInput
                  style={styles.textInput}
                  placeholder="At least 8 characters"
                  placeholderTextColor="#86968B"
                  secureTextEntry={!showPassword}
                  value={password}
                  onChangeText={(text) => {
                    setPassword(text);
                    if (fieldErrors.password) setFieldErrors({ ...fieldErrors, password: null });
                  }}
                />
                <TouchableOpacity
                  onPress={() => setShowPassword(!showPassword)}
                  style={styles.eyeBtn}
                  hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                >
                  <Ionicons
                    name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                    size={20}
                    color="#757575"
                  />
                </TouchableOpacity>
              </View>
              {fieldErrors.password ? (
                <Text style={styles.fieldErrorText}>{fieldErrors.password}</Text>
              ) : null}
            </View>

            {/* Confirm Password */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>
                Confirm Password <Text style={styles.asterisk}>*</Text>
              </Text>
              <View
                style={[
                  styles.inputWrapper,
                  fieldErrors.confirmPassword && styles.inputWrapperError,
                ]}
              >
                <Ionicons
                  name="shield-checkmark-outline"
                  size={20}
                  color={fieldErrors.confirmPassword ? '#C84B31' : '#344E41'}
                  style={styles.inputIcon}
                />
                <TextInput
                  style={styles.textInput}
                  placeholder="Re-enter your password"
                  placeholderTextColor="#86968B"
                  secureTextEntry={!showConfirmPassword}
                  value={confirmPassword}
                  onChangeText={(text) => {
                    setConfirmPassword(text);
                    if (fieldErrors.confirmPassword) {
                      setFieldErrors({ ...fieldErrors, confirmPassword: null });
                    }
                  }}
                />
                <TouchableOpacity
                  onPress={() => setShowConfirmPassword(!showConfirmPassword)}
                  style={styles.eyeBtn}
                  hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                >
                  <Ionicons
                    name={showConfirmPassword ? 'eye-off-outline' : 'eye-outline'}
                    size={20}
                    color="#757575"
                  />
                </TouchableOpacity>
              </View>
              {fieldErrors.confirmPassword ? (
                <Text style={styles.fieldErrorText}>{fieldErrors.confirmPassword}</Text>
              ) : null}
            </View>

            {/* Submit Button */}
            <TouchableOpacity
              style={[styles.submitBtn, isSubmitting && styles.submitBtnDisabled]}
              onPress={handleSignUp}
              disabled={isSubmitting}
              activeOpacity={0.85}
            >
              {isSubmitting ? (
                <ActivityIndicator color="#FFFFFF" size="small" />
              ) : (
                <>
                  <Text style={styles.submitBtnText}>Create Account</Text>
                  <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
                </>
              )}
            </TouchableOpacity>
          </View>

          {/* Switch to Sign In */}
          <View style={styles.switchAuthRow}>
            <Text style={styles.switchAuthPrompt}>Already have an account? </Text>
            <TouchableOpacity
              onPress={() => navigation.navigate('SignIn', { initialRole: 'Customer' })}
            >
              <Text style={styles.switchAuthLink}>Sign In</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#F8F5EC',
  },
  container: {
    paddingHorizontal: 20,
    paddingBottom: 36,
  },
  topNav: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    paddingHorizontal: 8,
    borderRadius: 8,
  },
  backButtonText: {
    color: '#344E41',
    fontSize: 14,
    fontWeight: '700',
    marginLeft: 4,
  },
  topNavTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: '#344E41',
  },
  header: {
    alignItems: 'center',
    marginTop: 4,
    marginBottom: 18,
  },
  logoCircle: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#344E41',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
    ...SHADOWS.sm,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    color: '#344E41',
    marginBottom: 4,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 13,
    color: '#56655A',
    textAlign: 'center',
    maxWidth: 290,
    lineHeight: 18,
    marginBottom: 10,
  },
  roleNoticeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EBF0E6',
    borderWidth: 1,
    borderColor: '#CCD6BD',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 14,
    gap: 6,
  },
  roleNoticeText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#344E41',
  },
  successBanner: {
    backgroundColor: '#EBF0E6',
    borderWidth: 1,
    borderColor: '#CCD6BD',
    borderRadius: 14,
    padding: 16,
    marginBottom: 16,
  },
  successHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  successTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: '#344E41',
  },
  successBody: {
    fontSize: 13,
    color: '#26352B',
    lineHeight: 18,
    marginBottom: 12,
  },
  successSignInBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#D97757',
    paddingVertical: 10,
    borderRadius: 10,
    gap: 6,
  },
  successSignInBtnText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 14,
  },
  errorBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FDF1EE',
    borderWidth: 1,
    borderColor: '#F8CDC3',
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
    gap: 8,
  },
  errorBannerText: {
    flex: 1,
    fontSize: 13,
    color: '#C84B31',
    lineHeight: 18,
  },
  formCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 20,
    borderWidth: 1,
    borderColor: '#EDE8DB',
    marginBottom: 20,
    ...SHADOWS.md,
  },
  inputGroup: {
    marginBottom: 14,
  },
  inputLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: '#26352B',
    marginBottom: 6,
  },
  asterisk: {
    color: '#C84B31',
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FAF8F3',
    borderWidth: 1,
    borderColor: '#EDE8DB',
    borderRadius: 12,
    paddingHorizontal: 12,
  },
  inputWrapperError: {
    borderColor: '#C84B31',
    backgroundColor: '#FDF1EE',
  },
  inputIcon: {
    marginRight: 10,
  },
  textInput: {
    flex: 1,
    height: 48,
    fontSize: 14,
    color: '#26352B',
  },
  eyeBtn: {
    padding: 6,
  },
  fieldErrorText: {
    color: '#C84B31',
    fontSize: 11,
    marginTop: 4,
    marginLeft: 4,
  },
  submitBtn: {
    flexDirection: 'row',
    backgroundColor: '#D97757',
    height: 50,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 8,
    gap: 8,
    shadowColor: '#D97757',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
    elevation: 3,
  },
  submitBtnDisabled: {
    opacity: 0.7,
  },
  submitBtnText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
  },
  switchAuthRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 8,
  },
  switchAuthPrompt: {
    fontSize: 13,
    color: '#56655A',
  },
  switchAuthLink: {
    fontSize: 13,
    fontWeight: '700',
    color: '#D97757',
  },
});
