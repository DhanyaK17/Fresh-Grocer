/**
 * Security Utilities (Demo Authentication)
 *
 * NOTE: This application is a frontend-only demo with no backend or database.
 * To satisfy the requirement of NEVER storing passwords in plain text in AsyncStorage,
 * this module creates a deterministic salted hash for mock authentication purposes.
 * It is clearly designated for frontend demo storage only and not as a production security substitute.
 */

const DEMO_SALT = 'GroceryApp_DemoSalt_2026_';

/**
 * Creates a deterministic hashed string representation of a password with salt.
 * Ensures plain text passwords are never stored in AsyncStorage.
 */
export function hashPassword(plainPassword) {
  if (!plainPassword) return '';

  const salted = DEMO_SALT + plainPassword;
  let hash = 0x811c9dc5;

  for (let i = 0; i < salted.length; i++) {
    hash ^= salted.charCodeAt(i);
    hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
  }

  // Convert to 32-bit unsigned hex string prefixed with demo marker
  const hexHash = (hash >>> 0).toString(16).padStart(8, '0');
  return `ghash_demo_${hexHash}_${salted.length}`;
}

/**
 * Verifies if a plain password matches a stored password hash.
 */
export function verifyPassword(plainPassword, storedHash) {
  if (!plainPassword || !storedHash) return false;
  return hashPassword(plainPassword) === storedHash;
}
