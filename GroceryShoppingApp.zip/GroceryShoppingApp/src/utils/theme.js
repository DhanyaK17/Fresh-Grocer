/**
 * Shared Design System & Theme Tokens for Grocery Shopping App
 * 
 * Premium Color Palette:
 * - Main background: #F8F5EC (warm cream)
 * - Product cards and content surfaces: #FFFFFF (clean white)
 * - Primary action buttons: #D97757 (terracotta)
 * - Small decorative accents & category highlights: #A3B18A (sage green)
 * - Navbar, headings and footer: #344E41 (deep forest green)
 * - Main text: #26352B (charcoal green)
 */

export const COLORS = {
  // Primary Palette Tokens
  primary: '#D97757',          // Terracotta for primary action buttons (Add to Cart, Shop Now, Checkout)
  terracotta: '#D97757',       // Explicit terracotta token
  terracottaDark: '#C25E3E',   // Pressed / active terracotta
  terracottaLight: '#FBECE8',  // Soft terracotta wash

  forestGreen: '#344E41',      // Deep forest green for navbar, headings, and footer
  primaryDark: '#344E41',      // Forest green heading token
  
  sageGreen: '#A3B18A',        // Sage green for accents and selected category highlights
  accent: '#A3B18A',           // Accent alias
  sageGreenLight: '#EBF0E6',   // Soft sage tint for badge / pill backgrounds
  primaryLight: '#EBF0E6',     // Light decorative accent tint
  sageGreenMuted: '#CCD6BD',   // Subtle sage border
  primaryMuted: '#CCD6BD',     // Muted accent border

  // Neutrals & Surfaces
  background: '#F8F5EC',       // Warm cream main page background
  backgroundWarm: '#F8F5EC',   // Explicit warm cream
  card: '#FFFFFF',             // Pure white for product cards, forms, content surfaces
  surface: '#FFFFFF',          // Content surfaces
  cardBorder: '#EDE8DB',       // Soft warm border for cards
  divider: '#EAE4D6',          // Warm dividing line

  // Typography
  textPrimary: '#26352B',      // Charcoal green for readable high-contrast main text
  textSecondary: '#56655A',    // Medium charcoal green for descriptions and subtitles
  textMuted: '#86968B',        // Soft muted text for placeholders
  textHeadings: '#344E41',     // Deep forest green for titles and headings
  textWhite: '#FFFFFF',        // White text for dark surfaces

  // Status & Role Accents
  adminBlue: '#2A5D74',        // Deep ocean slate for Admin role
  adminBlueLight: '#EBF2F5',   // Light admin background tint
  danger: '#C84B31',           // Terracotta-red for errors, delete actions
  dangerLight: '#FDF1EE',      // Light danger tint
  dangerBorder: '#F8CDC3',     // Danger border
  warning: '#D49B35',          // Warm gold for star ratings
  warningLight: '#FDF6E7',     // Soft gold badge background
  heartRed: '#D97757',         // Terracotta favorite heart accent
  heartRedLight: '#FBECE8',    // Soft heart background
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
};

export const RADIUS = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  pill: 999,
};

export const SHADOWS = {
  sm: {
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 1,
  },
  md: {
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.07,
    shadowRadius: 6,
    elevation: 2,
  },
  lg: {
    shadowColor: '#344E41',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 3,
  },
  card: {
    shadowColor: '#26352B',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
};
