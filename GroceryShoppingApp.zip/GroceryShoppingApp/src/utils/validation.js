/**
 * Form Validation Utilities for Sign In & Sign Up
 */

export const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
export const PHONE_REGEX = /^[+]?[(]?[0-9]{3}[)]?[-\s.]?[0-9]{3}[-\s.]?[0-9]{4,6}$/;

/**
 * Validates an email address.
 */
export function isValidEmail(email) {
  if (!email || typeof email !== 'string') return false;
  return EMAIL_REGEX.test(email.trim());
}

/**
 * Validates a phone number (minimum 10 digits).
 */
export function isValidPhone(phone) {
  if (!phone || typeof phone !== 'string') return false;
  const digitsOnly = phone.replace(/\D/g, '');
  return digitsOnly.length >= 10 && digitsOnly.length <= 15;
}

/**
 * Validates password minimum length (>= 8 characters).
 */
export function isValidPassword(password) {
  if (!password || typeof password !== 'string') return false;
  return password.length >= 8;
}

/**
 * Validates the Customer Sign Up form.
 * Returns an object with `isValid` boolean and a dictionary of field-specific errors.
 */
export function validateSignUpForm({ name, email, phone, password, confirmPassword }) {
  const errors = {};

  // Name validation
  if (!name || !name.trim()) {
    errors.name = 'Full Name is required.';
  } else if (name.trim().length < 2) {
    errors.name = 'Full Name must be at least 2 characters.';
  }

  // Email validation
  if (!email || !email.trim()) {
    errors.email = 'Email address is required.';
  } else if (!isValidEmail(email)) {
    errors.email = 'Please enter a valid email address (e.g. name@example.com).';
  }

  // Phone validation
  if (!phone || !phone.trim()) {
    errors.phone = 'Phone number is required.';
  } else if (!isValidPhone(phone)) {
    errors.phone = 'Please enter a valid phone number with at least 10 digits.';
  }

  // Password validation
  if (!password) {
    errors.password = 'Password is required.';
  } else if (!isValidPassword(password)) {
    errors.password = 'Password must be at least 8 characters long.';
  }

  // Confirm password validation
  if (!confirmPassword) {
    errors.confirmPassword = 'Confirm Password is required.';
  } else if (password !== confirmPassword) {
    errors.confirmPassword = 'Passwords do not match.';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}

/**
 * Validates the Sign In form.
 */
export function validateSignInForm({ email, password }) {
  const errors = {};

  if (!email || !email.trim()) {
    errors.email = 'Email address is required.';
  } else if (!isValidEmail(email)) {
    errors.email = 'Please enter a valid email address.';
  }

  if (!password) {
    errors.password = 'Password is required.';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}

/**
 * Validates the Edit Profile form.
 */
export function validateEditProfileForm({ name, email, phone }) {
  const errors = {};

  if (!name || !name.trim()) {
    errors.name = 'Full Name is required.';
  } else if (name.trim().length < 2) {
    errors.name = 'Full Name must be at least 2 characters.';
  }

  if (!email || !email.trim()) {
    errors.email = 'Email address is required.';
  } else if (!isValidEmail(email)) {
    errors.email = 'Please enter a valid email address.';
  }

  if (!phone || !phone.trim()) {
    errors.phone = 'Phone number is required.';
  } else if (!isValidPhone(phone)) {
    errors.phone = 'Please enter a valid phone number (at least 10 digits).';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}
