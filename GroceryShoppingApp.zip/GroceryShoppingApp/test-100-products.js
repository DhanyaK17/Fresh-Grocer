/**
 * Comprehensive Test Suite for the 100 New Grocery Products (20 per Category)
 * Verifies schema integrity, category counts, uniqueness, image URLs, and filter/search operations.
 */

const assert = require('assert');
const { PRODUCTS, CATEGORIES } = require('./src/data/products');

console.log('====================================================');
console.log('TEST SUITE: 100 NEW GROCERY PRODUCTS VALIDATION');
console.log('====================================================\n');

// 1. TOTAL PRODUCTS & CATEGORY COUNTS
console.log('--- Test 1: Category Product Counts ---');
const originalProducts = [
  'prod_1', 'prod_2', 'prod_3', // Fruits: 3
  'prod_4', 'prod_5', 'prod_6', // Vegetables: 3
  'prod_7', 'prod_8', 'prod_9', // Dairy: 3
  'prod_10', 'prod_11',         // Bakery: 2
  'prod_12', 'prod_13', 'prod_14', // Essentials: 3
];

console.log(`Total Products in Catalog: ${PRODUCTS.length}`);
assert.strictEqual(PRODUCTS.length, 114, 'Total catalog must have exactly 114 products (14 original + 100 new)');

// Verify all original 14 products are preserved
originalProducts.forEach((origId) => {
  const found = PRODUCTS.find((p) => p.id === origId);
  assert.ok(found, `Original product ${origId} must be preserved`);
});
console.log('✓ All 14 original products are preserved intact.');

// Verify exactly 20 new products per category
const categories = ['Fruits', 'Vegetables', 'Dairy', 'Bakery', 'Essentials'];
const expectedTotalByCategory = {
  Fruits: 23,     // 3 original + 20 new
  Vegetables: 23, // 3 original + 20 new
  Dairy: 23,      // 3 original + 20 new
  Bakery: 22,     // 2 original + 20 new
  Essentials: 23, // 3 original + 20 new
};

const countsByCategory = {};
const newProductsByCategory = {};

categories.forEach((cat) => {
  const prods = PRODUCTS.filter((p) => p.category.toLowerCase() === cat.toLowerCase());
  countsByCategory[cat] = prods.length;
  const newProds = prods.filter((p) => !originalProducts.includes(p.id));
  newProductsByCategory[cat] = newProds.length;

  console.log(`Category [${cat}]: Total = ${prods.length} (Original = ${prods.length - newProds.length}, New = ${newProds.length})`);
  assert.strictEqual(
    newProds.length,
    20,
    `Category ${cat} must have exactly 20 NEW products (found ${newProds.length})`
  );
  assert.strictEqual(
    prods.length,
    expectedTotalByCategory[cat],
    `Category ${cat} total must be ${expectedTotalByCategory[cat]} (found ${prods.length})`
  );
});
console.log('✓ Exactly 20 new products added to each of the 5 categories (100 new products total).\n');

// 2. SCHEMA INTEGRITY
console.log('--- Test 2: Product Schema & Field Completeness ---');
PRODUCTS.forEach((product, idx) => {
  assert.ok(typeof product.id === 'string' && product.id.trim().length > 0, `Product #${idx} must have non-empty string id`);
  assert.ok(typeof product.name === 'string' && product.name.trim().length > 0, `Product #${idx} must have non-empty name`);
  assert.ok(categories.includes(product.category), `Product ${product.id} category (${product.category}) must be valid`);
  assert.ok(typeof product.price === 'number' && product.price > 0, `Product ${product.id} price (${product.price}) must be positive number`);
  assert.ok(typeof product.unit === 'string' && product.unit.trim().length > 0, `Product ${product.id} unit (${product.unit}) must be string`);
  assert.ok(typeof product.rating === 'number' && product.rating >= 1 && product.rating <= 5, `Product ${product.id} rating must be 1.0 - 5.0`);
  assert.ok(typeof product.description === 'string' && product.description.trim().length > 10, `Product ${product.id} must have description`);
  assert.ok(typeof product.image === 'string' && product.image.startsWith('http'), `Product ${product.id} image must be a valid URL`);
  assert.strictEqual(typeof product.inStock, 'boolean', `Product ${product.id} inStock must be boolean`);
});
console.log('✓ All 114 products comply with complete schema (id, name, category, price, unit, rating, description, image, inStock).\n');

// 3. UNIQUENESS CHECKS
console.log('--- Test 3: ID and Name Uniqueness ---');
const ids = new Set();
const names = new Set();
PRODUCTS.forEach((p) => {
  assert.ok(!ids.has(p.id), `Duplicate ID detected: ${p.id}`);
  ids.add(p.id);

  const normalizedName = p.name.trim().toLowerCase();
  assert.ok(!names.has(normalizedName), `Duplicate Product Name detected: ${p.name}`);
  names.add(normalizedName);
});
console.log(`✓ 114 unique product IDs confirmed.`);
console.log(`✓ 114 unique product names confirmed (zero duplicate names).\n`);

// 4. CATEGORIES LIST
console.log('--- Test 4: Category Metadata ---');
assert.strictEqual(CATEGORIES.length, 6, 'CATEGORIES array must have 6 items (All + 5 categories)');
const catNames = CATEGORIES.map((c) => c.name);
['All', 'Fruits', 'Vegetables', 'Dairy', 'Bakery', 'Essentials'].forEach((name) => {
  assert.ok(catNames.includes(name), `CATEGORIES must include ${name}`);
});
console.log('✓ Categories metadata valid.\n');

// 5. SEARCH & FILTER SIMULATION
console.log('--- Test 5: Search and Filtering Simulation ---');
// Test category filter 'fruits'
const fruitFilter = PRODUCTS.filter((p) => p.category.toLowerCase() === 'fruits');
assert.strictEqual(fruitFilter.length, 23);

// Test category filter 'bakery'
const bakeryFilter = PRODUCTS.filter((p) => p.category.toLowerCase() === 'bakery');
assert.strictEqual(bakeryFilter.length, 22);

// Test search 'organic'
const organicSearch = PRODUCTS.filter(
  (p) => p.name.toLowerCase().includes('organic') || p.description.toLowerCase().includes('organic')
);
assert.ok(organicSearch.length > 5, `Expected multiple organic products, found: ${organicSearch.length}`);
console.log(`Search 'organic' matched ${organicSearch.length} items`);

// Test search 'paneer'
const paneerSearch = PRODUCTS.filter((p) => p.name.toLowerCase().includes('paneer'));
assert.ok(paneerSearch.length >= 1, `Expected paneer products, found: ${paneerSearch.length}`);
console.log(`Search 'paneer' matched: ${paneerSearch.map((p) => p.name).join(', ')}`);

// Test search 'cheese'
const cheeseSearch = PRODUCTS.filter((p) => p.name.toLowerCase().includes('cheese'));
assert.ok(cheeseSearch.length >= 3, `Expected cheese products, found: ${cheeseSearch.length}`);
console.log(`Search 'cheese' matched: ${cheeseSearch.map((p) => p.name).join(', ')}`);

// Test search 'bread'
const breadSearch = PRODUCTS.filter((p) => p.name.toLowerCase().includes('bread'));
assert.ok(breadSearch.length >= 4, `Expected bread products, found: ${breadSearch.length}`);
console.log(`Search 'bread' matched: ${breadSearch.map((p) => p.name).join(', ')}`);
console.log('✓ Search and category filtering simulations passed.\n');

// 6. CART & FAVORITES COMPATIBILITY
console.log('--- Test 6: Cart & Favorites Simulation ---');
// Mock cart calculations
const sampleCart = [
  { ...PRODUCTS[0], quantity: 2 },  // Apples ₹180 * 2 = 360
  { ...PRODUCTS[15], quantity: 1 }, // New Fruit
  { ...PRODUCTS[35], quantity: 3 }, // New Veg
  { ...PRODUCTS[75], quantity: 2 }, // New Bakery
];
const subtotal = sampleCart.reduce((sum, item) => sum + item.price * item.quantity, 0);
const itemCount = sampleCart.reduce((sum, item) => sum + item.quantity, 0);
assert.ok(subtotal > 0, 'Subtotal should be greater than 0');
assert.strictEqual(itemCount, 8, 'Total cart item count is 8');
console.log(`Cart simulation: Subtotal = ₹${subtotal}, Total Items = ${itemCount}`);
console.log('✓ Cart & Favorites compatibility confirmed.\n');

console.log('====================================================');
console.log('ALL TESTS PASSED: 100 NEW PRODUCTS SUCCESSFULLY VALIDATED!');
console.log('====================================================');
