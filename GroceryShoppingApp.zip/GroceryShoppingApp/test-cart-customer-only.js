/**
 * Automated Test Suite: My Cart Screen Must Be Available Only for Customers
 */

const assert = require('assert');
const fs = require('fs');

console.log('--- Test Group 1: Admin Navigation Exclusions ---');
const tabFile = fs.readFileSync('./src/navigation/TabNavigator.js', 'utf8');
const drawerFile = fs.readFileSync('./src/navigation/DrawerNavigator.js', 'utf8');
const adminNavFile = fs.readFileSync('./src/navigation/AdminNavigator.js', 'utf8');

// 1. Admin Tab Navigator should NOT contain Cart
const adminTabSection = tabFile.slice(tabFile.indexOf('export function AdminTabNavigator'));
assert.ok(!adminTabSection.includes('name="AdminCartTab"'), 'AdminTabNavigator must NOT have Cart tab');
assert.ok(!adminTabSection.includes('component={CartScreen}'), 'AdminTabNavigator must NOT mount CartScreen');
assert.ok(adminTabSection.includes('name="AdminHomeTab"'), 'AdminTabNavigator still has Home tab');
assert.ok(adminTabSection.includes('name="AdminProductsTab"'), 'AdminTabNavigator still has Products tab');
console.log('✓ Admin Tab Navigator verified: Cart tab removed, Home and Products preserved.');

// 2. Admin Drawer Navigator should NOT contain Cart
const adminDrawerSection = drawerFile.slice(drawerFile.indexOf('export function AdminDrawerNavigator'));
assert.ok(!adminDrawerSection.includes('name="Cart"'), 'AdminDrawerNavigator must NOT have Cart drawer item');
assert.ok(!adminDrawerSection.includes('component={CartScreen}'), 'AdminDrawerNavigator must NOT mount CartScreen');
assert.ok(adminDrawerSection.includes('name="AdminHomeDrawer"'), 'AdminDrawerNavigator still has Home');
assert.ok(adminDrawerSection.includes('name="Products"'), 'AdminDrawerNavigator still has Products');
console.log('✓ Admin Drawer Navigator verified: Cart drawer option removed, Home and Products preserved.');

// 3. Customer Tab and Drawer Navigators MUST have Cart
const customerTabSection = tabFile.slice(tabFile.indexOf('export function CustomerTabNavigator'), tabFile.indexOf('export function AdminTabNavigator'));
assert.ok(customerTabSection.includes('name="CartTab"'), 'CustomerTabNavigator has Cart tab');
assert.ok(customerTabSection.includes('tabBarBadge: cartCount'), 'Customer Cart tab has dynamic badge');

const customerDrawerSection = drawerFile.slice(drawerFile.indexOf('export function CustomerDrawerNavigator'), drawerFile.indexOf('export function AdminDrawerNavigator'));
assert.ok(customerDrawerSection.includes('name="Cart"'), 'CustomerDrawerNavigator has Cart option');
console.log('✓ Customer Navigation verified: Cart tab and drawer options intact with badge.');

console.log('\n--- Test Group 2: Screen UI Cart Button Safeguards ---');
// 4. HomeScreen checks
const homeFile = fs.readFileSync('./src/screens/HomeScreen.js', 'utf8');
assert.ok(homeFile.includes('isCustomer &&'), 'HomeScreen has isCustomer guard for navigation tiles');
assert.ok(homeFile.includes('navigation.navigate(\'Cart\')'), 'HomeScreen navigates to Cart for customer');
// Ensure the Cart tile is inside the isCustomer block
const cartTileIndex = homeFile.indexOf('navigation.navigate(\'Cart\')');
const isCustomerBeforeCart = homeFile.lastIndexOf('isCustomer &&', cartTileIndex);
assert.ok(isCustomerBeforeCart !== -1, 'My Cart tile is strictly inside isCustomer check on HomeScreen');
console.log('✓ HomeScreen verified: My Cart tile rendered only for Customer.');

// 5. ProductsScreen checks
const productsFile = fs.readFileSync('./src/screens/ProductsScreen.js', 'utf8');
assert.ok(productsFile.includes('{isCustomer && ('), 'CartBadgeIcon rendered conditionally with isCustomer');
const cartBadgeIndex = productsFile.indexOf('<CartBadgeIcon');
const isCustomerBeforeBadge = productsFile.lastIndexOf('isCustomer &&', cartBadgeIndex);
assert.ok(isCustomerBeforeBadge !== -1, 'CartBadgeIcon is conditionally rendered only for Customer on ProductsScreen');
console.log('✓ ProductsScreen verified: CartBadgeIcon rendered only for Customer.');

// 6. ProductCard checks
const productCardFile = fs.readFileSync('./src/components/ProductCard.js', 'utf8');
assert.ok(productCardFile.includes('{isCustomer ? ('), 'ProductCard checks isCustomer before showing Add to Cart button');
assert.ok(productCardFile.includes('styles.inStockBadge'), 'ProductCard renders In Stock badge for Admin');
console.log('✓ ProductCard verified: Add to Cart button rendered only for Customer.');

console.log('\n--- Test Group 3: CartScreen Route Guard & Admin Redirection ---');
const cartScreenFile = fs.readFileSync('./src/screens/CartScreen.js', 'utf8');
assert.ok(cartScreenFile.includes('userRole === \'Admin\''), 'CartScreen checks userRole === Admin');
assert.ok(cartScreenFile.includes('navigation.navigate(\'Products\')'), 'CartScreen redirects Admin to Products screen');
assert.ok(cartScreenFile.includes('Access Restricted'), 'CartScreen shows Access Restricted notice for Admin');
assert.ok(cartScreenFile.includes('restrictedContainer'), 'CartScreen returns safe restricted view without cart data');
console.log('✓ CartScreen route protection verified: Admin access blocked and redirected to Products.');

console.log('\n--- Test Group 4: Customer Cart State & Math Logic ---');
// Test Cart calculations logic
const mockProduct1 = { id: 'prod_1', name: 'Fresh Apples', price: 180 };
const mockProduct2 = { id: 'prod_2', name: 'Organic Bananas', price: 60 };

let cart = [];
function addToCart(product, qty = 1) {
  const existing = cart.find((i) => i.id === product.id);
  if (existing) {
    existing.quantity += qty;
  } else {
    cart.push({ id: product.id, product, quantity: qty });
  }
}
function increaseQuantity(id) {
  const item = cart.find((i) => i.id === id);
  if (item) item.quantity += 1;
}
function decreaseQuantity(id) {
  const item = cart.find((i) => i.id === id);
  if (item && item.quantity > 1) {
    item.quantity -= 1;
  }
}
function removeFromCart(id) {
  cart = cart.filter((i) => i.id !== id);
}

// 1. Add product to cart
addToCart(mockProduct1, 1);
assert.strictEqual(cart.length, 1, 'Product added to cart');
assert.strictEqual(cart[0].product.name, 'Fresh Apples', 'Product details match');
assert.strictEqual(cart[0].quantity, 1, 'Quantity is 1');

// 2. Increase quantity
increaseQuantity('prod_1');
assert.strictEqual(cart[0].quantity, 2, 'Quantity increased to 2');
let subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
assert.strictEqual(subtotal, 360, 'Subtotal is 180 * 2 = 360');

// 3. Add second product
addToCart(mockProduct2, 3);
assert.strictEqual(cart.length, 2, 'Second product added to cart');
subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
assert.strictEqual(subtotal, 360 + 180, 'Subtotal is 540');
let deliveryFee = subtotal >= 500 ? 0 : 40;
assert.strictEqual(deliveryFee, 0, 'Free delivery unlocked at >= 500');
let finalTotal = subtotal + deliveryFee;
assert.strictEqual(finalTotal, 540, 'Final total is 540');

// 4. Decrease quantity
decreaseQuantity('prod_2');
assert.strictEqual(cart.find((i) => i.id === 'prod_2').quantity, 2, 'Quantity decreased to 2');
subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
assert.strictEqual(subtotal, 360 + 120, 'Subtotal is 480');
deliveryFee = subtotal >= 500 ? 0 : 40;
assert.strictEqual(deliveryFee, 40, 'Standard delivery fee charged below 500');
finalTotal = subtotal + deliveryFee;
assert.strictEqual(finalTotal, 520, 'Final total is 480 + 40 = 520');

// 5. Remove products
removeFromCart('prod_1');
removeFromCart('prod_2');
assert.strictEqual(cart.length, 0, 'Cart is empty after removal');
console.log('✓ Customer Cart state, add/increase/decrease/remove, and totals verified.');

console.log('\n======================================================');
console.log('ALL MY CART ROLE-BASED TESTS PASSED SUCCESSFULLY! (4/4)');
console.log('======================================================');
