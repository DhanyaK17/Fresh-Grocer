/**
 * Complete UI Polish & Figma Design Matching Verification Test
 */

const assert = require('assert');
const fs = require('fs');

console.log('--- Test 1: Design Tokens & Theme Consistency ---');
const { COLORS, SPACING, RADIUS, SHADOWS } = require('./src/utils/theme');
assert.strictEqual(COLORS.primary, '#D97757', 'Primary terracotta is #D97757');
assert.strictEqual(COLORS.primaryDark, '#344E41', 'Forest green headings is #344E41');
assert.strictEqual(COLORS.primaryLight, '#EBF0E6', 'Sage green light accent is #EBF0E6');
assert.strictEqual(COLORS.background, '#F8F5EC', 'Background warm cream is #F8F5EC');
assert.strictEqual(COLORS.adminBlue, '#2A5D74', 'Admin blue is #2A5D74');
assert.strictEqual(COLORS.danger, '#C84B31', 'Danger red is #C84B31');
assert.ok(SHADOWS.sm && SHADOWS.md && SHADOWS.lg, 'Shadow tokens defined');
console.log('✓ Theme tokens verified.');

console.log('\n--- Test 2: Screen Imports & Syntax Check ---');
const screens = [
  'HomeScreen',
  'SignInScreen',
  'SignUpScreen',
  'ProductsScreen',
  'ProductDetailsScreen',
  'FavoritesScreen',
  'CartScreen',
  'ProfileScreen',
  'EditProfileScreen',
  'DeleteProfileScreen',
];

screens.forEach((screenName) => {
  const filePath = `./src/screens/${screenName}.js`;
  assert.ok(fs.existsSync(filePath), `${screenName} file exists`);
  const content = fs.readFileSync(filePath, 'utf8');
  assert.ok(content.length > 200, `${screenName} has valid content`);
  assert.ok(content.includes('export default function ' + screenName), `${screenName} exports default component`);
});
console.log(`✓ All ${screens.length} screens verified and intact.`);

console.log('\n--- Test 3: Components & UI Elements Check ---');
const components = ['CartBadgeIcon', 'CategoryFilter', 'ProductCard'];
components.forEach((compName) => {
  const filePath = `./src/components/${compName}.js`;
  assert.ok(fs.existsSync(filePath), `${compName} file exists`);
  const content = fs.readFileSync(filePath, 'utf8');
  assert.ok(content.includes('export default function ' + compName), `${compName} exports component`);
});

// Check ProductCard elements
const productCardFile = fs.readFileSync('./src/components/ProductCard.js', 'utf8');
assert.ok(productCardFile.includes('ratingBadge'), 'ProductCard has star rating chip');
assert.ok(productCardFile.includes('categoryBadge'), 'ProductCard has category badge');
assert.ok(productCardFile.includes('priceText'), 'ProductCard has formatted price');
assert.ok(productCardFile.includes('addCartBtn'), 'ProductCard has add to cart button');

// Check CategoryFilter elements
const categoryFilterFile = fs.readFileSync('./src/components/CategoryFilter.js', 'utf8');
assert.ok(categoryFilterFile.includes('categoryPillActive'), 'CategoryFilter has active highlight pill');

// Check CartBadgeIcon elements
const cartBadgeFile = fs.readFileSync('./src/components/CartBadgeIcon.js', 'utf8');
assert.ok(cartBadgeFile.includes('totalItemCount'), 'CartBadgeIcon reads live totalItemCount');
console.log('✓ Shared UI components verified.');

console.log('\n--- Test 4: Tab & Drawer Navigation Polish Check ---');
const tabFile = fs.readFileSync('./src/navigation/TabNavigator.js', 'utf8');
assert.ok(tabFile.includes('tabBarBadge'), 'TabNavigator includes dynamic cart badge');
assert.ok(tabFile.includes('focused ?'), 'TabNavigator switches to filled icons when focused');

const drawerFile = fs.readFileSync('./src/navigation/DrawerNavigator.js', 'utf8');
assert.ok(drawerFile.includes('FreshGrocer'), 'Drawer header has branded title');
assert.ok(drawerFile.includes("drawerActiveBackgroundColor: '#EBF0E6'"), 'Drawer has active tint background');
assert.ok(drawerFile.includes('promptDeleteProfileFromDrawer'), 'Customer drawer triggers delete confirmation');
assert.ok(drawerFile.includes('Log Out'), 'Drawer footer includes logout confirmation');
console.log('✓ Tab and Drawer navigation polish verified.');

console.log('\n--- Test 5: Cart Calculation Formulae Check ---');
const sampleItems = [
  { id: '1', product: { price: 180 }, quantity: 2 }, // 360
  { id: '2', product: { price: 60 }, quantity: 1 },  // 60
];
const subtotal = sampleItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
assert.strictEqual(subtotal, 420, 'Subtotal calculation is accurate');
const deliveryFee = subtotal >= 500 ? 0 : 40;
assert.strictEqual(deliveryFee, 40, 'Delivery fee is 40 when under 500');
const finalTotal = subtotal + deliveryFee;
assert.strictEqual(finalTotal, 460, 'Final total is accurate');

const freeDeliverySubtotal = 550;
const freeDeliveryFee = freeDeliverySubtotal >= 500 ? 0 : 40;
assert.strictEqual(freeDeliveryFee, 0, 'Delivery fee is 0 when 500 or above');
console.log('✓ Cart pricing and delivery thresholds verified.');

console.log('\n=========================================');
console.log('ALL UI POLISH & DESIGN TESTS PASSED! (5/5)');
console.log('=========================================');
